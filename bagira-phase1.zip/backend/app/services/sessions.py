"""Guest sessions: opaque random cookie token, stored only as a SHA-256 hash."""

import hashlib
import secrets
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.db.base import utcnow
from app.models import User, UserPreference, UserSession

LAST_SEEN_REFRESH = timedelta(minutes=5)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def create_guest(db: Session, settings: Settings, user_agent: str | None) -> tuple[User, str]:
    """Create a guest user with default preferences and a session. Returns (user, raw_token)."""
    user = User(is_guest=True, display_name="Guest")
    db.add(user)
    db.flush()
    user.display_name = f"Guest {str(user.id)[-4:]}"
    db.add(UserPreference(user_id=user.id))

    token = secrets.token_urlsafe(32)
    now = utcnow()
    db.add(
        UserSession(
            user_id=user.id,
            token_hash=hash_token(token),
            created_at=now,
            last_seen_at=now,
            expires_at=now + timedelta(days=settings.session_ttl_days),
            user_agent=(user_agent or "")[:255] or None,
        )
    )
    db.commit()
    return user, token


def resolve_session(db: Session, raw_token: str | None) -> UserSession | None:
    """Return the live session for a cookie token, or None if missing, expired or revoked."""
    if not raw_token or len(raw_token) > 200:
        return None
    session = db.scalar(select(UserSession).where(UserSession.token_hash == hash_token(raw_token)))
    if session is None or session.revoked_at is not None:
        return None
    now = utcnow()
    expires_at = session.expires_at
    if expires_at.tzinfo is None:  # SQLite returns naive datetimes; values are stored as UTC
        expires_at = expires_at.replace(tzinfo=now.tzinfo)
    if expires_at <= now or not session.user.is_active:
        return None

    last_seen = session.last_seen_at
    if last_seen.tzinfo is None:
        last_seen = last_seen.replace(tzinfo=now.tzinfo)
    if now - last_seen > LAST_SEEN_REFRESH:
        session.last_seen_at = now
        db.commit()
    return session
