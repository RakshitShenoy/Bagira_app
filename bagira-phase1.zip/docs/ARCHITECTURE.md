# Architecture

```
Browser (React / Vite / TypeScript)
  getUserMedia -> MediaPipe Hand Landmarker (WASM, in the browser)
  21 landmarks + handedness
        |  Phase 3: WebSocket, ~63 numbers per frame, never video
        v
FastAPI --- REST ---> SQLAlchemy 2 ---> SQLite (dev) / PostgreSQL (prod), Alembic migrations
  normalise -> classifier -> {gesture, confidence}          (Phase 2/3)

ml/  (separate package, never imported by the web app)
  validate -> parse -> crop -> landmarks -> normalise -> grouped split -> train -> evaluate -> export
```

Built in Phase 1: everything above except the classifier, the WebSocket and the ML pipeline.

## Decisions

1. **One `users` table for guests and accounts.** A guest is a user with `is_guest = true` and no
   credentials. Creating an account later fills in email and password on the same row, so a guest's data
   never has to be moved. Sessions (`user_sessions`) serve both.
2. **Session cookie, opaque token.** 256-bit random token in an `HttpOnly`, `SameSite=Lax` cookie
   (`Secure` in production). Only its SHA-256 hash is stored. Sessions can expire and be revoked.
3. **One origin.** In development Vite proxies `/api`; in Docker nginx does. Cookies stay first-party
   and CORS is not needed. Hosting the API on another site needs `SameSite=None; Secure` plus CSRF
   protection (Phase 6 review).
4. **Constraints live in the database** (checks, unique, foreign keys with explicit `ON DELETE`), and
   tests verify the database itself rejects bad data, on SQLite and PostgreSQL.
5. **UUIDv7 primary keys** for user-facing rows (time-ordered, no row-count leakage); integers for
   reference data and append-only logs.
6. **One error envelope** for every API error: `{"error": {"code", "message", "request_id"}}`; validation
   errors never echo submitted values.
7. **MediaPipe assets are self-hosted** (WASM copied from the npm package, model downloaded at build) so
   the app does not depend on a third-party CDN at runtime.
8. **Handedness correction in one place.** MediaPipe assumes mirrored input; Bagira sends the raw frame
   and swaps the label (`handedness.ts`). Phase 2 must keep landmark chirality consistent between
   training images and live frames; the classifier should not rely on the Left/Right label.
9. **No-hand is not a class.** Frames with no detected hand never reach the classifier. `no_gesture` is a
   real class for relaxed hands and is marked non-triggerable.
10. **ML stays separate.** Datasets, landmark CSVs and models are git-ignored and never share the
    application database.

## Known risks carried forward

- Training landmarks (Python MediaPipe on still images) and live landmarks (browser MediaPipe on video)
  must be shown to agree before the classifier is trusted (Phase 2/3 test).
- HaGRID is CC BY-SA 4.0: attribution is required.
- Free hosting tiers lose local disk on redeploy, so production needs external PostgreSQL and object
  storage (Phase 6).
