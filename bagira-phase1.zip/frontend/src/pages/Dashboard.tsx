import { useCallback, useEffect, useState } from 'react'
import { ButtonLink, Button, Spinner } from '../components/ui'
import { fetchReadiness } from '../lib/api'
import type { Readiness } from '../lib/types'
import { useSession } from '../session/SessionProvider'

const PLANNED = [
  'Gesture recognition and reactions',
  'Reaction library and custom GIF uploads',
  'Gesture roulette and rarity',
  'History, streaks and achievements',
  'Mini-games',
]

function ServerStatus() {
  const [readiness, setReadiness] = useState<Readiness | null>(null)
  const [attempt, setAttempt] = useState(0)

  useEffect(() => {
    let cancelled = false
    void fetchReadiness().then((result) => {
      if (!cancelled) setReadiness(result)
    })
    return () => {
      cancelled = true
    }
  }, [attempt])

  const check = useCallback(() => {
    setReadiness(null)
    setAttempt((n) => n + 1)
  }, [])

  if (!readiness) return <Spinner label="Checking the server…" />

  const copy = {
    ready: { text: 'Server and database are ready.', dot: 'bg-jade' },
    unavailable: { text: 'The server is running, but its database is not ready.', dot: 'bg-amber' },
    unreachable: { text: 'The server can’t be reached.', dot: 'bg-ember' },
  }[readiness.status]

  return (
    <div>
      <p className="flex items-center gap-2.5">
        <span aria-hidden="true" className={`size-2.5 rounded-full ${copy.dot}`} />
        {copy.text}
      </p>
      {readiness.schema_revision && (
        <p className="mt-1 text-sm text-bone/60">Database schema {readiness.schema_revision}</p>
      )}
      {readiness.status !== 'ready' && (
        <Button variant="quiet" className="mt-3 -ml-4" onClick={check}>
          Check again
        </Button>
      )}
    </div>
  )
}

export default function Dashboard() {
  const { user } = useSession()
  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
        Welcome, {user?.display_name}
      </h1>
      <p className="mt-2 max-w-prose text-bone/70">
        You’re using Bagira as a guest. Your settings are saved in this browser’s session.
      </p>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <section className="relative overflow-hidden rounded-[2.25rem] border border-bone/15 bg-moss/60 p-8 sm:p-10">
          <h2 className="font-display text-2xl font-semibold sm:text-3xl">Check your camera</h2>
          <p className="mt-3 max-w-md text-bone/75">
            Start the camera and watch Bagira track your hand with 21 points. This is the base
            that gesture recognition will build on.
          </p>
          <ButtonLink to="/app/camera" className="mt-7">
            Open the camera
          </ButtonLink>
        </section>

        <div className="space-y-6">
          <section className="rounded-3xl border border-bone/15 bg-canopy/80 p-6">
            <h2 className="font-display text-lg font-semibold">Server</h2>
            <div className="mt-3">
              <ServerStatus />
            </div>
          </section>

          <section className="rounded-3xl border border-bone/15 bg-canopy/80 p-6">
            <h2 className="font-display text-lg font-semibold">Coming in later releases</h2>
            <ul className="mt-3 space-y-2 text-bone/70">
              {PLANNED.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </section>
        </div>
      </div>
    </div>
  )
}
