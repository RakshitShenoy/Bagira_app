import { describe, expect, it } from 'vitest'
import { CAMERA_ERROR_COPY, describeCameraError } from './cameraErrors'

function domError(name: string) {
  return new DOMException('x', name)
}

describe('describeCameraError', () => {
  it.each([
    ['NotAllowedError', 'denied'],
    ['NotFoundError', 'no-device'],
    ['OverconstrainedError', 'no-device'],
    ['NotReadableError', 'in-use'],
    ['SecurityError', 'insecure'],
    ['SomethingElse', 'unknown'],
  ])('maps %s to %s', (name, kind) => {
    expect(describeCameraError(domError(name))).toBe(kind)
  })

  it('handles non-error values', () => {
    expect(describeCameraError('boom')).toBe('unknown')
    expect(describeCameraError(null)).toBe('unknown')
  })

  it('has user-facing copy for every kind', () => {
    for (const copy of Object.values(CAMERA_ERROR_COPY)) {
      expect(copy.title.length).toBeGreaterThan(5)
      expect(copy.body.length).toBeGreaterThan(20)
    }
  })
})
