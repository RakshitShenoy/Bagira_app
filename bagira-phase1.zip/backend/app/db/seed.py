"""Idempotent reference data. Run with: python -m app.db.seed

Seeds only gesture definitions (the 19 intended classes). It never touches user data and never
overwrites rows that already exist.
"""

import logging

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Gesture

logger = logging.getLogger("bagira.seed")

# (key, label, description, is_triggerable). `key` must equal the classifier's class label.
GESTURES: list[tuple[str, str, str, bool]] = [
    ("call", "Call", "Thumb and pinky out, like a phone.", True),
    ("no_gesture", "No gesture", "A relaxed hand that is not making a gesture.", False),
    ("dislike", "Dislike", "Thumbs down.", True),
    ("fist", "Fist", "A closed fist.", True),
    ("four", "Four", "Four fingers up, thumb tucked.", True),
    ("like", "Like", "Thumbs up.", True),
    ("mute", "Mute", "One finger across the lips.", True),
    ("ok", "OK", "Thumb and index finger joined in a circle.", True),
    ("one", "One", "Index finger pointing up.", True),
    ("palm", "Palm", "Open hand facing the camera.", True),
    ("peace", "Peace", "Index and middle fingers in a V.", True),
    ("peace_inverted", "Peace (inverted)", "A V sign with the palm facing you.", True),
    ("rock", "Rock", "Index finger and pinky raised.", True),
    ("stop", "Stop", "Flat hand held up like a stop sign.", True),
    ("stop_inverted", "Stop (inverted)", "A stop sign with the hand turned over.", True),
    ("three", "Three", "Index, middle and ring fingers up.", True),
    ("three2", "Three (alt)", "Thumb, index and middle fingers up.", True),
    ("two_up", "Two up", "Index and middle fingers pointing up together.", True),
    ("two_up_inverted", "Two up (inverted)", "Two fingers pointing down.", True),
]


def seed_gestures(session: Session) -> int:
    """Insert any missing gestures. Returns how many rows were created."""
    existing = set(session.scalars(select(Gesture.key)))
    created = 0
    for order, (key, label, description, triggerable) in enumerate(GESTURES):
        if key in existing:
            continue
        session.add(
            Gesture(
                key=key,
                label=label,
                description=description,
                is_triggerable=triggerable,
                sort_order=order,
            )
        )
        created += 1
    session.commit()
    return created


def main() -> None:
    from app.core.config import get_settings
    from app.core.logging import configure_logging
    from app.db.session import create_db_engine, create_session_factory

    settings = get_settings()
    configure_logging(settings)
    engine = create_db_engine(settings.database_url)
    with create_session_factory(engine)() as session:
        created = seed_gestures(session)
    logger.info("gestures_seeded", extra={"rows_created": created, "total": len(GESTURES)})


if __name__ == "__main__":
    main()
