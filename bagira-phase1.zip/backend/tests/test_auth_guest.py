from datetime import timedelta

from sqlalchemy import select, update

from app.db.base import utcnow
from app.models import User, UserPreference, UserSession
from app.services.sessions import hash_token


def test_guest_session_is_created_with_secure_cookie_flags(client):
    r = client.post("/api/v1/auth/guest")
    assert r.status_code == 201
    body = r.json()
    assert body["is_guest"] is True and body["display_name"].startswith("Guest")
    cookie = r.headers["set-cookie"].lower()
    assert "httponly" in cookie and "samesite=lax" in cookie and "path=/" in cookie
    assert "; secure" not in cookie  # development runs over http; production sets Secure


def test_cookie_gets_secure_flag_when_enabled(settings):
    from fastapi.testclient import TestClient

    from app.core.config import Settings
    from app.main import create_app

    secure = Settings(
        env="test", database_url=settings.database_url, cookie_secure=True, _env_file=None
    )
    with TestClient(create_app(secure)) as c:
        r = c.post("/api/v1/auth/guest")
    assert "; secure" in r.headers["set-cookie"].lower()


def test_me_returns_the_guest(client):
    created = client.post("/api/v1/auth/guest").json()
    me = client.get("/api/v1/me")
    assert me.status_code == 200
    assert me.json()["id"] == created["id"]


def test_starting_guest_twice_reuses_the_session(client, db):
    first = client.post("/api/v1/auth/guest")
    second = client.post("/api/v1/auth/guest")
    assert first.status_code == 201 and second.status_code == 200
    assert first.json()["id"] == second.json()["id"]
    assert len(db.scalars(select(User)).all()) == 1


def test_me_requires_a_session(client):
    r = client.get("/api/v1/me")
    assert r.status_code == 401
    assert r.json()["error"]["code"] == "not_authenticated"


def test_tampered_cookie_is_rejected(client):
    client.post("/api/v1/auth/guest")
    client.cookies.set("bagira_session", "not-a-real-token")
    assert client.get("/api/v1/me").status_code == 401


def test_raw_token_is_never_stored(client, db):
    token = client.post("/api/v1/auth/guest").cookies["bagira_session"]
    stored = db.scalar(select(UserSession))
    assert stored.token_hash == hash_token(token) and stored.token_hash != token
    assert token not in str(stored.__dict__)


def test_expired_session_is_rejected(client, db):
    client.post("/api/v1/auth/guest")
    db.execute(
        update(UserSession).values(
            expires_at=utcnow() - timedelta(seconds=1), created_at=utcnow() - timedelta(days=2)
        )
    )
    db.commit()
    assert client.get("/api/v1/me").status_code == 401


def test_revoked_session_is_rejected(client, db):
    client.post("/api/v1/auth/guest")
    db.execute(update(UserSession).values(revoked_at=utcnow()))
    db.commit()
    assert client.get("/api/v1/me").status_code == 401


def test_deactivated_user_is_rejected(client, db):
    client.post("/api/v1/auth/guest")
    db.execute(update(User).values(is_active=False))
    db.commit()
    assert client.get("/api/v1/me").status_code == 401


def test_guest_gets_default_preferences(client, db):
    client.post("/api/v1/auth/guest")
    assert db.scalar(select(UserPreference)) is not None


def test_timestamps_are_utc_in_every_response(client):
    created = client.post("/api/v1/auth/guest").json()["created_at"]
    assert created.endswith("Z") or created.endswith("+00:00")
    assert client.get("/api/v1/me").json()["created_at"] == created
