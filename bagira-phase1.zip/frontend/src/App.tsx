import { lazy, Suspense } from 'react'
import { MotionConfig } from 'framer-motion'
import { BrowserRouter, Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom'
import AppLayout from './components/AppLayout'
import { Button, Spinner, StatePanel } from './components/ui'
import Dashboard from './pages/Dashboard'
import Landing from './pages/Landing'
import NotFound from './pages/NotFound'
import Settings from './pages/Settings'
import { SessionProvider, useSession } from './session/SessionProvider'

// The camera page pulls in MediaPipe, so it loads only when someone opens it.
const CameraPage = lazy(() => import('./pages/CameraPage'))

function FullScreen({ children }: { children: React.ReactNode }) {
  return <div className="bg-ambient grid min-h-dvh place-items-center p-6">{children}</div>
}

function RequireSession() {
  const { status, error, retry } = useSession()
  const location = useLocation()

  if (status === 'loading') {
    return (
      <FullScreen>
        <Spinner label="Loading Bagira…" />
      </FullScreen>
    )
  }
  if (status === 'error') {
    return (
      <FullScreen>
        <div className="max-w-md">
          <StatePanel
            tone="error"
            title="Bagira can’t reach its server"
            action={<Button onClick={retry}>Try again</Button>}
          >
            {error}
          </StatePanel>
        </div>
      </FullScreen>
    )
  }
  if (status === 'anonymous') return <Navigate to="/" replace state={{ from: location.pathname }} />
  return <Outlet />
}

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <SessionProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/app" element={<RequireSession />}>
              <Route element={<AppLayout />}>
                <Route index element={<Dashboard />} />
                <Route
                  path="camera"
                  element={
                    <Suspense fallback={<Spinner label="Loading camera…" />}>
                      <CameraPage />
                    </Suspense>
                  }
                />
                <Route path="settings" element={<Settings />} />
              </Route>
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </SessionProvider>
    </MotionConfig>
  )
}
