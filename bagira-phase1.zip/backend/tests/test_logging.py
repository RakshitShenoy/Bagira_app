import json
import logging

from app.core.logging import JsonFormatter, request_id_var


def test_json_formatter_includes_extras_and_request_id():
    record = logging.LogRecord(
        "bagira.test", logging.INFO, __file__, 1, "hello %s", ("world",), None
    )
    record.status = 200
    token = request_id_var.set("abc12345")
    try:
        record.request_id = request_id_var.get()
        payload = json.loads(JsonFormatter().format(record))
    finally:
        request_id_var.reset(token)
    assert payload["message"] == "hello world"
    assert payload["level"] == "INFO"
    assert payload["status"] == 200
    assert payload["request_id"] == "abc12345"
