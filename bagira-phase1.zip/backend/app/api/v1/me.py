from fastapi import APIRouter

from app.api.deps import CurrentUser, DbSession
from app.models import UserPreference
from app.schemas.user import PreferencesOut, PreferencesPatch, UserOut

router = APIRouter(tags=["me"])


@router.get("/me", response_model=UserOut)
def read_me(user: CurrentUser) -> UserOut:
    return UserOut.model_validate(user)


def _preferences_for(db: DbSession, user: CurrentUser) -> UserPreference:
    preference = db.get(UserPreference, user.id)
    if preference is None:  # defensive: every user is created with one
        preference = UserPreference(user_id=user.id)
        db.add(preference)
        db.flush()
    return preference


@router.get("/preferences", response_model=PreferencesOut)
def read_preferences(user: CurrentUser, db: DbSession) -> PreferencesOut:
    preference = _preferences_for(db, user)
    db.commit()
    return PreferencesOut.model_validate(preference)


@router.patch("/preferences", response_model=PreferencesOut)
def update_preferences(patch: PreferencesPatch, user: CurrentUser, db: DbSession) -> PreferencesOut:
    preference = _preferences_for(db, user)
    for field, value in patch.model_dump(exclude_none=True).items():
        setattr(preference, field, value)
    db.commit()
    return PreferencesOut.model_validate(preference)
