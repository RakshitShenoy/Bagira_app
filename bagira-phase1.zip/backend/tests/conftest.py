"""Test fixtures. Tests run against real Alembic migrations, never against create_all().

By default each test gets a fresh SQLite file. Set BAGIRA_TEST_DATABASE_URL to a PostgreSQL URL
to run the very same suite against PostgreSQL (CI does this).
"""

import os
from collections.abc import Iterator

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from alembic import command
from app.core.config import Settings
from app.db.migrations import alembic_config
from app.db.seed import seed_gestures
from app.db.session import create_db_engine, create_session_factory
from app.main import create_app

PG_URL = os.environ.get("BAGIRA_TEST_DATABASE_URL")


@pytest.fixture
def database_url(tmp_path) -> Iterator[str]:
    url = PG_URL or f"sqlite:///{tmp_path / 'test.db'}"
    config = alembic_config(url)
    config.attributes["configure_logger"] = False
    if PG_URL:
        command.downgrade(config, "base")
    command.upgrade(config, "head")
    yield url
    if PG_URL:
        command.downgrade(config, "base")


@pytest.fixture
def settings(database_url) -> Settings:
    return Settings(env="test", database_url=database_url, secret_key="test-secret", _env_file=None)


@pytest.fixture
def db(settings) -> Iterator[Session]:
    engine = create_db_engine(settings.database_url)
    with create_session_factory(engine)() as session:
        yield session
    engine.dispose()


@pytest.fixture
def client(settings) -> Iterator[TestClient]:
    with TestClient(create_app(settings)) as test_client:
        yield test_client


@pytest.fixture
def make_client(settings):
    """Factory for extra clients (each has its own cookie jar), e.g. to test data isolation."""
    clients: list[TestClient] = []

    def _make() -> TestClient:
        tc = TestClient(create_app(settings))
        tc.__enter__()
        clients.append(tc)
        return tc

    yield _make
    for tc in clients:
        tc.__exit__(None, None, None)


@pytest.fixture
def seeded_db(db) -> Session:
    seed_gestures(db)
    return db
