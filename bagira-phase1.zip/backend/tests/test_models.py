"""The database itself must refuse bad data (constraints, foreign keys, cascades)."""

from datetime import timedelta

import pytest
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError

from app.db.base import utcnow
from app.models import (
    Gesture,
    GestureMapping,
    MediaAsset,
    MiniGameRecord,
    ReactionEvent,
    User,
    UserPreference,
    UserSession,
)
from app.models.enums import MediaKind, MediaSource, MediaStatus, ReactionTrigger


def make_user(db, **kw) -> User:
    user = User(display_name=kw.pop("display_name", "Tester"), **kw)
    db.add(user)
    db.commit()  # committed so a later expected rollback does not discard the user
    return user


def make_media(db, owner=None, **kw) -> MediaAsset:
    asset = MediaAsset(
        owner_id=owner.id if owner else None,
        kind=MediaKind.GIF,
        source=MediaSource.UPLOAD if owner else MediaSource.CURATED,
        status=MediaStatus.ACTIVE,
        title="cat",
        storage_key=kw.pop("storage_key", f"k/{utcnow().timestamp()}"),
        mime_type="image/gif",
        size_bytes=kw.pop("size_bytes", 1234),
        sha256="a" * 64,
        **kw,
    )
    db.add(asset)
    db.flush()
    return asset


def expect_rejected(db, fn):
    with pytest.raises(IntegrityError):
        fn()
        db.flush()
    db.rollback()


def test_guest_may_have_no_credentials(db):
    make_user(db, is_guest=True)


def test_account_requires_email_and_password(db):
    expect_rejected(db, lambda: make_user(db, is_guest=False))
    expect_rejected(db, lambda: make_user(db, is_guest=False, email="a@b.co"))
    make_user(db, is_guest=False, email="a@b.co", password_hash="x")


def test_email_must_be_lowercase_and_unique(db):
    expect_rejected(db, lambda: make_user(db, is_guest=False, email="A@B.co", password_hash="x"))
    make_user(db, is_guest=False, email="a@b.co", password_hash="x")
    expect_rejected(db, lambda: make_user(db, is_guest=False, email="a@b.co", password_hash="y"))


def test_session_expiry_must_follow_creation(db):
    user = make_user(db)
    now = utcnow()
    expect_rejected(
        db,
        lambda: db.add(
            UserSession(
                user_id=user.id,
                token_hash="h" * 64,
                created_at=now,
                expires_at=now - timedelta(seconds=1),
            )
        ),
    )


@pytest.mark.parametrize(
    "field,value",
    [("confidence_threshold", 1.5), ("stability_frames", 0), ("cooldown_ms", -1)],
)
def test_preference_ranges(db, field, value):
    user = make_user(db)
    expect_rejected(db, lambda: db.add(UserPreference(user_id=user.id, **{field: value})))


def test_mapping_needs_exactly_one_reaction(db, seeded_db):
    user = make_user(db)
    gesture = db.scalar(select(Gesture).where(Gesture.key == "like"))
    media = make_media(db)

    expect_rejected(db, lambda: db.add(GestureMapping(user_id=user.id, gesture_id=gesture.id)))
    expect_rejected(
        db,
        lambda: db.add(
            GestureMapping(
                user_id=user.id, gesture_id=gesture.id, media_id=media.id, effect_key="confetti"
            )
        ),
    )
    user = make_user(db)
    db.add(GestureMapping(user_id=user.id, gesture_id=gesture.id, effect_key="confetti"))
    db.flush()


def test_one_mapping_per_user_and_gesture(db, seeded_db):
    user = make_user(db)
    gesture = db.scalar(select(Gesture).where(Gesture.key == "fist"))
    db.add(GestureMapping(user_id=user.id, gesture_id=gesture.id, effect_key="a"))
    db.flush()
    expect_rejected(
        db, lambda: db.add(GestureMapping(user_id=user.id, gesture_id=gesture.id, effect_key="b"))
    )


def test_upload_must_have_owner(db):
    expect_rejected(
        db,
        lambda: db.add(
            MediaAsset(
                kind=MediaKind.GIF,
                source=MediaSource.UPLOAD,
                title="x",
                storage_key="u1",
                mime_type="image/gif",
                size_bytes=1,
                sha256="b" * 64,
            )
        ),
    )


def test_media_size_must_be_positive_and_key_unique(db):
    expect_rejected(db, lambda: make_media(db, size_bytes=0))
    make_media(db, storage_key="same")
    expect_rejected(db, lambda: make_media(db, storage_key="same"))


def test_reaction_confidence_and_gesture_rules(db, seeded_db):
    user = make_user(db)
    gesture = db.scalar(select(Gesture).where(Gesture.key == "palm"))
    expect_rejected(
        db,
        lambda: db.add(
            ReactionEvent(
                user_id=user.id,
                trigger=ReactionTrigger.GESTURE,
                gesture_id=gesture.id,
                confidence=1.2,
            )
        ),
    )
    # A gesture-triggered reaction must say which gesture.
    expect_rejected(
        db, lambda: db.add(ReactionEvent(user_id=user.id, trigger=ReactionTrigger.GESTURE))
    )
    db.add(ReactionEvent(user_id=user.id, trigger=ReactionTrigger.ROULETTE, effect_key="confetti"))
    db.flush()


def test_minigame_score_cannot_be_negative(db):
    user = make_user(db)
    expect_rejected(db, lambda: db.add(MiniGameRecord(user_id=user.id, game_key="x", score=-1)))
    db.add(MiniGameRecord(user_id=user.id, game_key="x", score=10, details={"combo": 3}))
    db.flush()


def test_invalid_enum_value_is_rejected_by_database(db):
    from sqlalchemy import text

    user = make_user(db)
    db.commit()
    with pytest.raises(IntegrityError):
        db.execute(
            text(
                "INSERT INTO reaction_events (user_id, trigger, created_at) "
                "VALUES (:u, 'nonsense', CURRENT_TIMESTAMP)"
            ),
            {"u": user.id.hex if db.bind.dialect.name == "sqlite" else user.id},
        )
    db.rollback()


def test_deleting_a_user_cascades_to_all_their_data(db, seeded_db):
    user = make_user(db)
    db.add(UserPreference(user_id=user.id))
    gesture = db.scalar(select(Gesture).where(Gesture.key == "ok"))
    media = make_media(db, owner=user)
    db.add(GestureMapping(user_id=user.id, gesture_id=gesture.id, media_id=media.id))
    db.add(ReactionEvent(user_id=user.id, trigger=ReactionTrigger.GESTURE, gesture_id=gesture.id))
    db.add(MiniGameRecord(user_id=user.id, game_key="g", score=1))
    now = utcnow()
    db.add(
        UserSession(
            user_id=user.id, token_hash="t" * 64, created_at=now, expires_at=now + timedelta(days=1)
        )
    )
    db.commit()

    db.delete(user)
    db.commit()

    for model in (
        UserPreference,
        GestureMapping,
        MediaAsset,
        ReactionEvent,
        MiniGameRecord,
        UserSession,
    ):
        assert db.scalar(select(func.count()).select_from(model)) == 0, model.__name__
    assert db.scalar(select(func.count()).select_from(Gesture)) == 19  # reference data untouched


def test_gesture_in_use_cannot_be_deleted(db, seeded_db):
    user = make_user(db)
    gesture = db.scalar(select(Gesture).where(Gesture.key == "one"))
    db.add(ReactionEvent(user_id=user.id, trigger=ReactionTrigger.GESTURE, gesture_id=gesture.id))
    db.commit()
    with pytest.raises(IntegrityError):
        db.delete(gesture)
        db.commit()
    db.rollback()
