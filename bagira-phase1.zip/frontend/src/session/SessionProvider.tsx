import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { api, ApiError } from '../lib/api'
import type { User } from '../lib/types'

export type SessionStatus = 'loading' | 'anonymous' | 'ready' | 'error'

interface SessionValue {
  status: SessionStatus
  user: User | null
  error: string | null
  startGuest: () => Promise<boolean>
  retry: () => void
}

const SessionContext = createContext<SessionValue | null>(null)

export function SessionProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<SessionStatus>('loading')
  const [user, setUser] = useState<User | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [attempt, setAttempt] = useState(0)

  useEffect(() => {
    let cancelled = false
    api<User>('/api/v1/me')
      .then((me) => {
        if (cancelled) return
        setUser(me)
        setStatus('ready')
      })
      .catch((err: unknown) => {
        if (cancelled) return
        if (err instanceof ApiError && err.status === 401) {
          setUser(null)
          setStatus('anonymous')
        } else {
          setError(err instanceof Error ? err.message : 'Something went wrong.')
          setStatus('error')
        }
      })
    return () => {
      cancelled = true
    }
  }, [attempt])

  const startGuest = useCallback(async () => {
    try {
      const guest = await api<User>('/api/v1/auth/guest', { method: 'POST' })
      setUser(guest)
      setError(null)
      setStatus('ready')
      return true
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong.')
      return false
    }
  }, [])

  const retry = useCallback(() => {
    setStatus('loading')
    setAttempt((n) => n + 1)
  }, [])

  const value = useMemo(
    () => ({ status, user, error, startGuest, retry }),
    [status, user, error, startGuest, retry],
  )
  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>
}

// eslint-disable-next-line react-refresh/only-export-components
export function useSession(): SessionValue {
  const value = useContext(SessionContext)
  if (!value) throw new Error('useSession must be used inside <SessionProvider>')
  return value
}
