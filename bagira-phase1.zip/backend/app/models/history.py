import uuid
from datetime import datetime
from typing import TYPE_CHECKING

import sqlalchemy as sa
from sqlalchemy import CheckConstraint, DateTime, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, BigIntPk, enum_type, utcnow
from app.models.enums import Rarity, ReactionTrigger

if TYPE_CHECKING:
    from app.models.user import User


class ReactionEvent(Base):
    """Append-only history: every reaction Bagira showed to a user."""

    __tablename__ = "reaction_events"
    __table_args__ = (
        CheckConstraint(
            "confidence IS NULL OR (confidence >= 0 AND confidence <= 1)", name="confidence_range"
        ),
        CheckConstraint("trigger != 'gesture' OR gesture_id IS NOT NULL", name="gesture_has_id"),
        sa.Index("ix_reaction_events_user_created", "user_id", "created_at"),
        sa.Index("ix_reaction_events_user_gesture", "user_id", "gesture_id"),
    )

    id: Mapped[int] = mapped_column(BigIntPk, primary_key=True, autoincrement=True)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    trigger: Mapped[ReactionTrigger] = mapped_column(enum_type(ReactionTrigger, "reaction_trigger"))
    gesture_id: Mapped[int | None] = mapped_column(
        ForeignKey("gestures.id", ondelete="RESTRICT"), index=True
    )
    media_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("media_assets.id", ondelete="SET NULL"), index=True
    )
    effect_key: Mapped[str | None] = mapped_column(String(40))
    confidence: Mapped[float | None] = mapped_column(sa.Float)
    rarity: Mapped[Rarity | None] = mapped_column(enum_type(Rarity, "rarity"))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, server_default=sa.func.now()
    )

    user: Mapped["User"] = relationship(back_populates="reactions")
