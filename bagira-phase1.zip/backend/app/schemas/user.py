import uuid
from datetime import UTC, datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    display_name: str
    is_guest: bool
    created_at: datetime

    @field_validator("created_at")
    @classmethod
    def _as_utc(cls, value: datetime) -> datetime:
        # SQLite hands back naive datetimes; everything is stored as UTC, so say so explicitly.
        return value.replace(tzinfo=UTC) if value.tzinfo is None else value


class PreferencesOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    mirror_camera: bool
    reduce_motion: bool
    sound_enabled: bool
    effects_enabled: bool
    fullscreen_reactions: bool
    confidence_threshold: float
    stability_frames: int
    cooldown_ms: int


class PreferencesPatch(BaseModel):
    """Partial update. Unknown fields are rejected rather than silently ignored."""

    model_config = ConfigDict(extra="forbid")

    mirror_camera: bool | None = None
    reduce_motion: bool | None = None
    sound_enabled: bool | None = None
    effects_enabled: bool | None = None
    fullscreen_reactions: bool | None = None
    confidence_threshold: float | None = Field(default=None, ge=0, le=1)
    stability_frames: int | None = Field(default=None, ge=1, le=60)
    cooldown_ms: int | None = Field(default=None, ge=0, le=60000)
