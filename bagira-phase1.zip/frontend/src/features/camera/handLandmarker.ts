import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision'

const WASM_BASE = String(import.meta.env.VITE_MEDIAPIPE_WASM_URL ?? '/mediapipe/wasm')
const MODEL_URL = String(
  import.meta.env.VITE_HAND_LANDMARKER_MODEL_URL ?? '/models/hand_landmarker.task',
)

export type LoadErrorKind = 'model-missing' | 'runtime' | 'unknown'

export class HandTrackingLoadError extends Error {
  kind: LoadErrorKind

  constructor(kind: LoadErrorKind, message: string) {
    super(message)
    this.name = 'HandTrackingLoadError'
    this.kind = kind
  }
}

async function assertModelAvailable(): Promise<void> {
  let response: Response
  try {
    response = await fetch(MODEL_URL, { method: 'HEAD' })
  } catch {
    throw new HandTrackingLoadError('runtime', 'The hand tracking model could not be downloaded.')
  }
  // Vite's dev server answers unknown paths with index.html, so also reject an HTML "model".
  const type = response.headers.get('content-type') ?? ''
  if (!response.ok || type.includes('text/html')) {
    throw new HandTrackingLoadError(
      'model-missing',
      'The hand tracking model file (hand_landmarker.task) is missing from this build.',
    )
  }
}

async function create(delegate: 'GPU' | 'CPU'): Promise<HandLandmarker> {
  const fileset = await FilesetResolver.forVisionTasks(WASM_BASE)
  return HandLandmarker.createFromOptions(fileset, {
    baseOptions: { modelAssetPath: MODEL_URL, delegate },
    runningMode: 'VIDEO',
    numHands: 2,
    minHandDetectionConfidence: 0.5,
    minHandPresenceConfidence: 0.5,
    minTrackingConfidence: 0.5,
  })
}

let cached: Promise<HandLandmarker> | null = null

/** Loads MediaPipe Hand Landmarker once per page. Prefers the GPU and falls back to the CPU. */
export function loadHandLandmarker(): Promise<HandLandmarker> {
  if (!cached) {
    cached = (async () => {
      await assertModelAvailable()
      try {
        return await create('GPU')
      } catch {
        try {
          return await create('CPU')
        } catch (err) {
          throw new HandTrackingLoadError(
            'runtime',
            `Hand tracking could not start: ${err instanceof Error ? err.message : 'unknown error'}`,
          )
        }
      }
    })().catch((err) => {
      cached = null // allow "Try again" to retry from scratch
      throw err
    })
  }
  return cached
}
