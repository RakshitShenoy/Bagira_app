from fastapi.testclient import TestClient

from app.core.config import Settings
from app.main import create_app


def test_health_ok(client):
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert body["app"] == "Bagira"


def test_ready_reports_migrated_schema(client):
    r = client.get("/health/ready")
    assert r.status_code == 200
    body = r.json()
    assert body == {
        "status": "ready",
        "database": "ok",
        "schema_revision": "0001",
        "schema_up_to_date": True,
    }


def test_ready_is_503_when_schema_not_migrated(tmp_path):
    settings = Settings(
        env="test", database_url=f"sqlite:///{tmp_path / 'empty.db'}", _env_file=None
    )
    with TestClient(create_app(settings)) as c:
        r = c.get("/health/ready")
    assert r.status_code == 503
    assert r.json()["schema_up_to_date"] is False


def test_request_id_is_generated_and_echoed(client):
    assert len(client.get("/health").headers["x-request-id"]) == 32
    r = client.get("/health", headers={"X-Request-ID": "trace-abc-12345"})
    assert r.headers["x-request-id"] == "trace-abc-12345"


def test_unsafe_request_id_is_replaced(client):
    r = client.get("/health", headers={"X-Request-ID": "bad id\twith spaces"})
    assert r.headers["x-request-id"] != "bad id\twith spaces"


def test_unknown_route_uses_error_envelope(client):
    r = client.get("/nope")
    assert r.status_code == 404
    err = r.json()["error"]
    assert err["code"] == "not_found"
    assert err["request_id"] == r.headers["x-request-id"]


def test_unexpected_exception_returns_generic_500(settings):
    app = create_app(settings)

    @app.get("/boom")
    def boom():
        raise RuntimeError("secret internal detail")

    with TestClient(app, raise_server_exceptions=False) as c:
        r = c.get("/boom")
    assert r.status_code == 500
    assert r.json()["error"]["code"] == "internal_error"
    assert "secret internal detail" not in r.text


def test_docs_disabled_in_production(tmp_path):
    s = Settings(
        env="production",
        database_url="postgresql://u:p@localhost/none",
        secret_key="x" * 40,
        _env_file=None,
    )
    app = create_app(s)
    assert app.docs_url is None and app.openapi_url is None
