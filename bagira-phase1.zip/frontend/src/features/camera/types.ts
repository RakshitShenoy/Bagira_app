import type { HandLabel } from './handedness'

export interface Landmark {
  x: number
  y: number
  z: number
}

export interface DetectedHand {
  label: HandLabel
  score: number
  landmarks: Landmark[]
}

export interface TrackingStats {
  fps: number
  inferenceMs: number
  hands: DetectedHand[]
}
