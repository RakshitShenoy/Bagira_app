import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { describe, expect, it } from 'vitest'
import { GUEST, jsonResponse, mockFetch } from '../test/helpers'
import { SessionProvider } from '../session/SessionProvider'
import Landing from './Landing'

const unauthenticated = () =>
  jsonResponse({ error: { code: 'not_authenticated', message: 'No session.' } }, 401)

function renderLanding() {
  return render(
    <SessionProvider>
      <MemoryRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/app" element={<p>dashboard reached</p>} />
        </Routes>
      </MemoryRouter>
    </SessionProvider>,
  )
}

describe('Landing', () => {
  it('shows the headline and a guest entry that needs no sign-up', async () => {
    mockFetch(unauthenticated)
    renderLanding()
    expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent(/Show a gesture\.\s*Bagira reacts\./)
    expect(await screen.findByRole('button', { name: 'Continue as guest' })).toBeEnabled()
    expect(screen.getByText('No sign-up needed.')).toBeInTheDocument()
  })

  it('starts a guest session and opens the dashboard', async () => {
    const fetchMock = mockFetch((url, init) => {
      if (url.endsWith('/auth/guest') && init?.method === 'POST') return jsonResponse(GUEST, 201)
      return unauthenticated()
    })
    renderLanding()
    await userEvent.click(await screen.findByRole('button', { name: 'Continue as guest' }))
    expect(await screen.findByText('dashboard reached')).toBeInTheDocument()
    expect(fetchMock.mock.calls.some(([u]) => String(u).endsWith('/api/v1/auth/guest'))).toBe(true)
  })

  it('explains the problem when the server cannot be reached, and offers a retry', async () => {
    mockFetch(() => {
      throw new TypeError('Failed to fetch')
    })
    renderLanding()
    expect(await screen.findByRole('alert')).toHaveTextContent(/Can.t reach the Bagira server/)
    expect(screen.getByRole('button', { name: 'Try again' })).toBeInTheDocument()
  })

  it('offers to continue when a session already exists', async () => {
    mockFetch(() => jsonResponse(GUEST))
    renderLanding()
    expect(await screen.findByRole('link', { name: 'Open the camera' })).toHaveAttribute('href', '/app/camera')
  })
})
