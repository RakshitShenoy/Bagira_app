import uuid
from typing import TYPE_CHECKING

import sqlalchemy as sa
from sqlalchemy import CheckConstraint, ForeignKey, String, UniqueConstraint, Uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, uuid7

if TYPE_CHECKING:
    from app.models.media import MediaAsset
    from app.models.user import User


class Gesture(Base):
    """Reference data: a gesture class the recogniser can output. `key` equals the model label."""

    __tablename__ = "gestures"

    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(32), unique=True)
    label: Mapped[str] = mapped_column(String(64))
    description: Mapped[str] = mapped_column(String(255), default="", server_default="")
    # False for classes that must never fire a reaction, such as no_gesture.
    is_triggerable: Mapped[bool] = mapped_column(default=True, server_default=sa.true())
    is_active: Mapped[bool] = mapped_column(default=True, server_default=sa.true())
    sort_order: Mapped[int] = mapped_column(default=0, server_default=sa.text("0"))


class GestureMapping(Base, TimestampMixin):
    """A user's chosen reaction for one gesture: either a media asset or a built-in effect."""

    __tablename__ = "gesture_mappings"
    __table_args__ = (
        UniqueConstraint("user_id", "gesture_id", name="uq_gesture_mappings_user_gesture"),
        CheckConstraint(
            "(media_id IS NOT NULL AND effect_key IS NULL) "
            "OR (media_id IS NULL AND effect_key IS NOT NULL)",
            name="exactly_one_reaction",
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid7)
    user_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    gesture_id: Mapped[int] = mapped_column(
        ForeignKey("gestures.id", ondelete="RESTRICT"), index=True
    )
    media_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("media_assets.id", ondelete="CASCADE"), index=True
    )
    effect_key: Mapped[str | None] = mapped_column(String(40))
    enabled: Mapped[bool] = mapped_column(default=True, server_default=sa.true())

    user: Mapped["User"] = relationship(back_populates="mappings")
    gesture: Mapped[Gesture] = relationship()
    media: Mapped["MediaAsset | None"] = relationship()
