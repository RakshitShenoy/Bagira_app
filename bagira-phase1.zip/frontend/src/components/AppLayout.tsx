import { MotionConfig } from 'framer-motion'
import { NavLink, Outlet } from 'react-router-dom'
import { PreferencesProvider, usePreferences } from '../session/PreferencesProvider'
import { useSession } from '../session/SessionProvider'
import { Logo } from './Logo'

const NAV = [
  { to: '/app', label: 'Dashboard', end: true, icon: 'M4 13h6V4H4v9Zm0 7h6v-5H4v5Zm10 0h6V11h-6v9Zm0-16v5h6V4h-6Z' },
  {
    to: '/app/camera',
    label: 'Camera',
    icon: 'M4 7h3l1.5-2h7L17 7h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1Zm8 3.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Z',
  },
  {
    to: '/app/settings',
    label: 'Settings',
    icon: 'M4 7h9m4 0h3M4 17h3m4 0h9M15 4v6m-8 4v6',
  },
]

function NavIcon({ d }: { d: string }) {
  return (
    <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" aria-hidden="true">
      <path d={d} />
    </svg>
  )
}

function Shell() {
  const { user } = useSession()
  const { preferences } = usePreferences()
  const link = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-3 rounded-2xl px-4 py-3 text-[0.95rem] font-medium transition-colors max-md:flex-col max-md:gap-1 max-md:px-2 max-md:py-2 max-md:text-xs ${
      isActive ? 'bg-moss text-bone' : 'text-bone/65 hover:bg-bone/10 hover:text-bone'
    }`

  return (
    <MotionConfig reducedMotion={preferences?.reduce_motion ? 'always' : 'user'}>
      <div className="bg-ambient min-h-dvh md:grid md:grid-cols-[15rem_minmax(0,1fr)]">
        <header className="hidden flex-col justify-between border-r border-bone/10 p-5 md:flex md:sticky md:top-0 md:h-dvh">
          <div>
            <Logo className="px-2 py-3" />
            <nav aria-label="Main" className="mt-6 flex flex-col gap-1">
              {NAV.map((item) => (
                <NavLink key={item.to} to={item.to} end={item.end} className={link}>
                  <NavIcon d={item.icon} />
                  {item.label}
                </NavLink>
              ))}
            </nav>
          </div>
          <p className="px-2 text-sm text-bone/60">
            {user?.display_name}
            {user?.is_guest ? ' · guest' : ''}
          </p>
        </header>

        <div className="flex items-center justify-between px-5 pt-5 md:hidden">
          <Logo />
          <span className="text-sm text-bone/60">{user?.display_name}</span>
        </div>

        <main id="main" className="px-5 pt-6 pb-28 md:px-10 md:py-10">
          <Outlet />
        </main>

        <nav
          aria-label="Main"
          className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-3 gap-1 border-t border-bone/10 bg-night/95 px-3 pt-2 backdrop-blur md:hidden"
          style={{ paddingBottom: 'max(0.5rem, env(safe-area-inset-bottom))' }}
        >
          {NAV.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end} className={link}>
              <NavIcon d={item.icon} />
              {item.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </MotionConfig>
  )
}

export default function AppLayout() {
  return (
    <PreferencesProvider>
      <Shell />
    </PreferencesProvider>
  )
}
