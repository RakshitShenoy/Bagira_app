import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { api } from '../lib/api'
import type { Preferences, PreferencesPatch } from '../lib/types'

type LoadStatus = 'loading' | 'ready' | 'error'

interface PreferencesValue {
  preferences: Preferences | null
  status: LoadStatus
  saveError: string | null
  update: (patch: PreferencesPatch) => Promise<void>
  reload: () => void
}

const PreferencesContext = createContext<PreferencesValue | null>(null)

export function PreferencesProvider({ children }: { children: ReactNode }) {
  const [preferences, setPreferences] = useState<Preferences | null>(null)
  const [status, setStatus] = useState<LoadStatus>('loading')
  const [saveError, setSaveError] = useState<string | null>(null)
  const [attempt, setAttempt] = useState(0)

  useEffect(() => {
    let cancelled = false
    api<Preferences>('/api/v1/preferences')
      .then((p) => {
        if (cancelled) return
        setPreferences(p)
        setStatus('ready')
      })
      .catch(() => {
        if (!cancelled) setStatus('error')
      })
    return () => {
      cancelled = true
    }
  }, [attempt])

  const update = useCallback(
    async (patch: PreferencesPatch) => {
      const previous = preferences
      if (!previous) return
      setSaveError(null)
      setPreferences({ ...previous, ...patch }) // optimistic, rolled back if the save fails
      try {
        setPreferences(await api<Preferences>('/api/v1/preferences', { method: 'PATCH', json: patch }))
      } catch (err) {
        setPreferences(previous)
        setSaveError(err instanceof Error ? err.message : 'Could not save that change.')
      }
    },
    [preferences],
  )

  const reload = useCallback(() => {
    setStatus('loading')
    setAttempt((n) => n + 1)
  }, [])
  const value = useMemo(
    () => ({ preferences, status, saveError, update, reload }),
    [preferences, status, saveError, update, reload],
  )
  return <PreferencesContext.Provider value={value}>{children}</PreferencesContext.Provider>
}

// eslint-disable-next-line react-refresh/only-export-components
export function usePreferences(): PreferencesValue {
  const value = useContext(PreferencesContext)
  if (!value) throw new Error('usePreferences must be used inside <PreferencesProvider>')
  return value
}
