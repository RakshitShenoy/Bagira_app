import { vi } from 'vitest'

export function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' },
  })
}

type Handler = (url: string, init?: RequestInit) => Response | Promise<Response>

/** Replaces global fetch with a handler keyed on the request; unknown routes fail loudly. */
export function mockFetch(handler: Handler) {
  const fn = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) =>
    handler(String(input), init),
  )
  vi.stubGlobal('fetch', fn)
  return fn
}

export const GUEST = {
  id: '01a1bf16-fcba-7fd9-8c9a-f662c74672d8',
  display_name: 'Guest 72d8',
  is_guest: true,
  created_at: '2026-11-09T06:55:17Z',
}

export const PREFS = {
  mirror_camera: true,
  reduce_motion: false,
  sound_enabled: true,
  effects_enabled: true,
  fullscreen_reactions: true,
  confidence_threshold: 0.8,
  stability_frames: 5,
  cooldown_ms: 1500,
}
