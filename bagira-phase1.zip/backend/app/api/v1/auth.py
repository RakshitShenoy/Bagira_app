from fastapi import APIRouter, Request, Response

from app.api.deps import AppSettings, DbSession
from app.schemas.user import UserOut
from app.services.sessions import create_guest, resolve_session

router = APIRouter(prefix="/auth", tags=["auth"])


def set_session_cookie(response: Response, settings, token: str) -> None:  # noqa: ANN001
    response.set_cookie(
        key=settings.session_cookie_name,
        value=token,
        max_age=settings.session_ttl_days * 86400,
        httponly=True,  # not readable from JavaScript
        secure=settings.effective_cookie_secure,
        samesite=settings.cookie_samesite,
        path="/",
    )


@router.post("/guest", response_model=UserOut, summary="Start (or resume) a guest session")
def start_guest(
    request: Request, response: Response, db: DbSession, settings: AppSettings
) -> UserOut:
    existing = resolve_session(db, request.cookies.get(settings.session_cookie_name))
    if existing is not None:
        return UserOut.model_validate(existing.user)  # idempotent: no new guest per click

    user, token = create_guest(db, settings, request.headers.get("user-agent"))
    set_session_cookie(response, settings, token)
    response.status_code = 201
    return UserOut.model_validate(user)
