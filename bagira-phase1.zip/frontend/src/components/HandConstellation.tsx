import { motion } from 'framer-motion'

// An idealised open hand in MediaPipe's 21-landmark layout (viewBox 0..100 x 0..120).
const POINTS: [number, number][] = [
  [50, 110], // 0 wrist
  [36, 98], [26, 86], [18, 74], [12, 63], // thumb
  [38, 70], [35, 50], [33, 36], [32, 24], // index
  [50, 66], [50, 44], [50, 29], [50, 16], // middle
  [62, 70], [65, 50], [67, 37], [68, 26], // ring
  [73, 78], [79, 63], [83, 52], [86, 43], // pinky
]
const BONES: [number, number][] = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [0, 5], [5, 6], [6, 7], [7, 8],
  [5, 9], [9, 10], [10, 11], [11, 12],
  [9, 13], [13, 14], [14, 15], [15, 16],
  [13, 17], [17, 18], [18, 19], [19, 20],
  [0, 17],
]
const TIPS = new Set([4, 8, 12, 16, 20])

/** The one orchestrated moment on the landing page: the hand draws itself, then settles. */
export function HandConstellation({ className = '' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 120"
      className={className}
      role="img"
      aria-label="A hand drawn as 21 connected tracking points"
    >
      <defs>
        <radialGradient id="palm-glow" cx="50%" cy="62%" r="55%">
          <stop offset="0" stopColor="var(--color-amber)" stopOpacity="0.28" />
          <stop offset="1" stopColor="var(--color-amber)" stopOpacity="0" />
        </radialGradient>
      </defs>
      <ellipse cx="50" cy="66" rx="52" ry="58" fill="url(#palm-glow)" />
      {BONES.map(([a, b], i) => (
        <motion.line
          key={`${a}-${b}`}
          x1={POINTS[a][0]}
          y1={POINTS[a][1]}
          x2={POINTS[b][0]}
          y2={POINTS[b][1]}
          stroke="var(--color-jade)"
          strokeWidth="0.9"
          strokeLinecap="round"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.85 }}
          transition={{ delay: 0.15 + i * 0.045, duration: 0.5, ease: 'easeOut' }}
        />
      ))}
      {POINTS.map(([x, y], i) => (
        <motion.circle
          key={i}
          cx={x}
          cy={y}
          r={TIPS.has(i) ? 2.4 : 1.6}
          fill={TIPS.has(i) ? 'var(--color-amber)' : 'var(--color-bone)'}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.25 + i * 0.045, type: 'spring', stiffness: 260, damping: 16 }}
          style={{ transformBox: 'fill-box', transformOrigin: 'center' }}
        />
      ))}
    </svg>
  )
}
