import { Button, Spinner, StatePanel, Switch } from '../components/ui'
import { usePreferences } from '../session/PreferencesProvider'
import { useSession } from '../session/SessionProvider'

export default function Settings() {
  const { user } = useSession()
  const { preferences, status, saveError, update, reload } = usePreferences()

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">Settings</h1>
      <p className="mt-2 text-bone/70">Changes save automatically.</p>

      <div className="mt-8 space-y-6">
        {status === 'loading' && <Spinner label="Loading your settings…" />}
        {status === 'error' && (
          <StatePanel
            tone="error"
            title="Your settings could not be loaded"
            action={<Button onClick={reload}>Try again</Button>}
          >
            Check that the Bagira server is running, then try again.
          </StatePanel>
        )}

        {preferences && (
          <section
            aria-label="Preferences"
            className="rounded-3xl border border-bone/15 bg-canopy/80 px-6 divide-y divide-bone/10 sm:px-8"
          >
            <Switch
              label="Mirror the camera preview"
              description="Show the camera like a mirror, so moving your right hand moves the picture to the right."
              checked={preferences.mirror_camera}
              onChange={(next) => void update({ mirror_camera: next })}
            />
            <Switch
              label="Reduce motion"
              description="Turn off animations across Bagira."
              checked={preferences.reduce_motion}
              onChange={(next) => void update({ reduce_motion: next })}
            />
          </section>
        )}

        {saveError && (
          <p role="alert" className="text-ember">
            {saveError}
          </p>
        )}

        <section className="rounded-3xl border border-bone/15 bg-canopy/80 p-6 sm:p-8">
          <h2 className="font-display text-lg font-semibold">Your session</h2>
          <p className="mt-2 text-bone/70">
            {user?.is_guest
              ? 'You’re a guest. Your data stays linked to this browser. Accounts, which let you keep it across devices, are planned for a later release.'
              : 'You’re signed in.'}
          </p>
        </section>

        <p className="text-sm text-bone/60">
          Sound, effects and recognition sensitivity settings will appear here once gesture
          recognition ships.
        </p>
      </div>
    </div>
  )
}
