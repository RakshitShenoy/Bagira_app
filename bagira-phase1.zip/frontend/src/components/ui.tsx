import type { ButtonHTMLAttributes, ReactNode } from 'react'
import { Link } from 'react-router-dom'
import type { LinkProps } from 'react-router-dom'

const base =
  'inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-base font-semibold transition-[background-color,transform,opacity] duration-150 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50'
const variants = {
  primary: 'bg-amber text-night hover:bg-[#f7bb52]',
  secondary: 'border border-bone/25 text-bone hover:bg-bone/10',
  quiet: 'px-4 py-2 text-bone/80 hover:bg-bone/10 hover:text-bone',
} as const
type Variant = keyof typeof variants

export function Button({
  variant = 'primary',
  className = '',
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return <button className={`${base} ${variants[variant]} ${className}`} {...props} />
}

export function ButtonLink({
  variant = 'primary',
  className = '',
  ...props
}: LinkProps & { variant?: Variant }) {
  return <Link className={`${base} ${variants[variant]} ${className}`} {...props} />
}

export function Spinner({ label }: { label: string }) {
  return (
    <span role="status" className="inline-flex items-center gap-3 text-bone/80">
      <span
        aria-hidden="true"
        className="size-5 animate-spin rounded-full border-2 border-bone/20 border-t-amber motion-reduce:animate-none"
      />
      <span>{label}</span>
    </span>
  )
}

/** One shape for "something is loading, failed, or is empty". */
export function StatePanel({
  tone = 'neutral',
  title,
  children,
  action,
}: {
  tone?: 'neutral' | 'error'
  title: string
  children?: ReactNode
  action?: ReactNode
}) {
  const border = tone === 'error' ? 'border-ember/40' : 'border-bone/15'
  return (
    <div
      role={tone === 'error' ? 'alert' : 'status'}
      className={`rounded-3xl border ${border} bg-canopy/80 p-6 sm:p-8`}
    >
      <h2 className="font-display text-xl font-semibold">{title}</h2>
      {children && <div className="mt-2 max-w-prose text-bone/70">{children}</div>}
      {action && <div className="mt-5 flex flex-wrap gap-3">{action}</div>}
    </div>
  )
}

export function Switch({
  checked,
  onChange,
  label,
  description,
  disabled,
}: {
  checked: boolean
  onChange: (next: boolean) => void
  label: string
  description?: string
  disabled?: boolean
}) {
  return (
    <div className="flex items-start justify-between gap-6 py-4">
      <div>
        <p className="font-medium">{label}</p>
        {description && <p className="mt-0.5 text-sm text-bone/65">{description}</p>}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={`relative mt-0.5 h-7 w-12 shrink-0 rounded-full transition-colors duration-150 disabled:opacity-50 ${
          checked ? 'bg-jade' : 'bg-bone/20'
        }`}
      >
        <span
          className={`absolute top-1 left-1 size-5 rounded-full bg-night transition-transform duration-150 ${
            checked ? 'translate-x-5' : ''
          }`}
        />
      </button>
    </div>
  )
}
