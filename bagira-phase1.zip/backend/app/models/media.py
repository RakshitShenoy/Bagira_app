import uuid
from datetime import datetime
from typing import TYPE_CHECKING

import sqlalchemy as sa
from sqlalchemy import CheckConstraint, DateTime, ForeignKey, String, Uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, enum_type, utcnow, uuid7
from app.models.enums import MediaKind, MediaSource, MediaStatus, Rarity

if TYPE_CHECKING:
    from app.models.user import User


class MediaAsset(Base):
    """Metadata for a GIF, image or sound. File bytes live in media storage, not in the database."""

    __tablename__ = "media_assets"
    __table_args__ = (
        CheckConstraint("size_bytes > 0", name="size_positive"),
        CheckConstraint("width IS NULL OR width > 0", name="width_positive"),
        CheckConstraint("height IS NULL OR height > 0", name="height_positive"),
        CheckConstraint("length(sha256) = 64", name="sha256_length"),
        CheckConstraint("source != 'upload' OR owner_id IS NOT NULL", name="upload_has_owner"),
        sa.Index("ix_media_assets_status_kind", "status", "kind"),
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid7)
    owner_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )  # NULL for curated and external assets
    kind: Mapped[MediaKind] = mapped_column(enum_type(MediaKind, "media_kind"))
    source: Mapped[MediaSource] = mapped_column(enum_type(MediaSource, "media_source"))
    status: Mapped[MediaStatus] = mapped_column(
        enum_type(MediaStatus, "media_status"),
        default=MediaStatus.PENDING,
        server_default=MediaStatus.PENDING.value,
    )
    title: Mapped[str] = mapped_column(String(120))
    category: Mapped[str | None] = mapped_column(String(40), index=True)
    rarity: Mapped[Rarity] = mapped_column(
        enum_type(Rarity, "rarity"), default=Rarity.COMMON, server_default=Rarity.COMMON.value
    )
    storage_key: Mapped[str] = mapped_column(String(255), unique=True)
    mime_type: Mapped[str] = mapped_column(String(100))
    size_bytes: Mapped[int] = mapped_column(sa.BigInteger)
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    width: Mapped[int | None]
    height: Mapped[int | None]
    duration_ms: Mapped[int | None]
    license: Mapped[str | None] = mapped_column(String(120))
    attribution: Mapped[str | None] = mapped_column(String(255))
    source_url: Mapped[str | None] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, server_default=sa.func.now()
    )

    owner: Mapped["User | None"] = relationship(back_populates="media_assets")
