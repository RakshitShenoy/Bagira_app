import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Any

import sqlalchemy as sa
from sqlalchemy import CheckConstraint, DateTime, ForeignKey, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, BigIntPk, utcnow

if TYPE_CHECKING:
    from app.models.user import User


class MiniGameRecord(Base):
    """One finished mini-game round."""

    __tablename__ = "mini_game_records"
    __table_args__ = (
        CheckConstraint("score >= 0", name="score_non_negative"),
        CheckConstraint("duration_ms IS NULL OR duration_ms >= 0", name="duration_non_negative"),
        sa.Index("ix_mini_game_records_game_score", "game_key", "score"),
        sa.Index("ix_mini_game_records_user_game", "user_id", "game_key", "played_at"),
    )

    id: Mapped[int] = mapped_column(BigIntPk, primary_key=True, autoincrement=True)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    game_key: Mapped[str] = mapped_column(String(40))
    score: Mapped[int]
    duration_ms: Mapped[int | None]
    details: Mapped[dict[str, Any] | None] = mapped_column(
        sa.JSON().with_variant(JSONB(), "postgresql")
    )
    played_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, server_default=sa.func.now()
    )

    user: Mapped["User"] = relationship(back_populates="game_records")
