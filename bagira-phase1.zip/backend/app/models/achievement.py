import uuid
from datetime import datetime
from typing import TYPE_CHECKING

import sqlalchemy as sa
from sqlalchemy import CheckConstraint, DateTime, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, utcnow

if TYPE_CHECKING:
    from app.models.user import User


class Achievement(Base):
    """Reference data: an achievement users can unlock once `threshold` is reached."""

    __tablename__ = "achievements"
    __table_args__ = (CheckConstraint("threshold >= 1", name="threshold_positive"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(48), unique=True)
    name: Mapped[str] = mapped_column(String(80))
    description: Mapped[str] = mapped_column(String(255))
    threshold: Mapped[int] = mapped_column(default=1, server_default=sa.text("1"))
    sort_order: Mapped[int] = mapped_column(default=0, server_default=sa.text("0"))
    is_active: Mapped[bool] = mapped_column(default=True, server_default=sa.true())


class UserAchievement(Base):
    """A user's progress on one achievement. unlocked_at is NULL while it is in progress."""

    __tablename__ = "user_achievements"
    __table_args__ = (CheckConstraint("progress >= 0", name="progress_non_negative"),)

    user_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), primary_key=True
    )
    achievement_id: Mapped[int] = mapped_column(
        ForeignKey("achievements.id", ondelete="CASCADE"), primary_key=True, index=True
    )
    progress: Mapped[int] = mapped_column(default=0, server_default=sa.text("0"))
    unlocked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow, server_default=sa.func.now()
    )

    user: Mapped["User"] = relationship(back_populates="achievements")
    achievement: Mapped[Achievement] = relationship()
