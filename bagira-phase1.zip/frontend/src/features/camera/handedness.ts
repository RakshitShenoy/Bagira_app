export type HandLabel = 'Left' | 'Right' | 'Unknown'

/**
 * MediaPipe decides Left/Right assuming the image is a mirrored selfie. Bagira feeds it the raw,
 * un-mirrored camera frame (mirroring is only a CSS effect on the preview), so the label it
 * returns is the opposite of the user's real hand. Swap it here, in exactly one place.
 */
export function physicalHand(modelLabel: string | undefined, feedIsMirrored = false): HandLabel {
  if (modelLabel !== 'Left' && modelLabel !== 'Right') return 'Unknown'
  if (feedIsMirrored) return modelLabel
  return modelLabel === 'Left' ? 'Right' : 'Left'
}
