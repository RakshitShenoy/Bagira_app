#!/bin/sh
# Apply migrations, load reference data, then start the API.
# Running migrations here is fine for one instance. With several replicas, run
# `alembic upgrade head` once as a separate release step instead.
set -e
alembic upgrade head
python -m app.db.seed
exec uvicorn app.main:get_asgi_app --factory \
    --host 0.0.0.0 --port "${PORT:-8000}" \
    --no-access-log --proxy-headers --forwarded-allow-ips "${FORWARDED_ALLOW_IPS:-127.0.0.1}"
