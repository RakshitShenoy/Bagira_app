from sqlalchemy import func, select

from app.db.seed import GESTURES, seed_gestures
from app.models import Gesture

INTENDED = {
    "call",
    "no_gesture",
    "dislike",
    "fist",
    "four",
    "like",
    "mute",
    "ok",
    "one",
    "palm",
    "peace",
    "peace_inverted",
    "rock",
    "stop",
    "stop_inverted",
    "three",
    "three2",
    "two_up",
    "two_up_inverted",
}


def test_seeds_exactly_the_19_intended_classes(db):
    assert seed_gestures(db) == 19
    keys = set(db.scalars(select(Gesture.key)))
    assert keys == INTENDED


def test_seed_is_idempotent_and_keeps_edits(db):
    seed_gestures(db)
    gesture = db.scalar(select(Gesture).where(Gesture.key == "palm"))
    gesture.label = "Edited"
    db.commit()
    assert seed_gestures(db) == 0
    assert db.scalar(select(func.count()).select_from(Gesture)) == len(GESTURES)
    assert db.scalar(select(Gesture.label).where(Gesture.key == "palm")) == "Edited"


def test_no_gesture_never_triggers_a_reaction(db):
    seed_gestures(db)
    flags = dict(db.execute(select(Gesture.key, Gesture.is_triggerable)).all())
    assert flags["no_gesture"] is False
    assert all(v for k, v in flags.items() if k != "no_gesture")


def test_seed_command_runs(settings, monkeypatch):
    """Regression: the CLI once crashed on a reserved logging field name."""
    from app.core.config import get_settings
    from app.db import seed

    monkeypatch.setenv("BAGIRA_DATABASE_URL", settings.database_url)
    get_settings.cache_clear()
    try:
        seed.main()
    finally:
        get_settings.cache_clear()
