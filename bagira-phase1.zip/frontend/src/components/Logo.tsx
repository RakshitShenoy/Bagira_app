export function LogoMark({ className = 'size-8' }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true" focusable="false">
      <path
        d="M2 16C6.5 9 11 6.5 16 6.5s9.5 2.5 14 9.5c-4.500 7-9 9.5-14 9.5S6.5 23 2 16Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinejoin="round"
      />
      <circle cx="16" cy="16" r="6.2" fill="var(--color-amber)" />
      <ellipse cx="16" cy="16" rx="1.6" ry="5.8" fill="var(--color-night)" />
    </svg>
  )
}

export function Logo({ className = '' }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <LogoMark />
      <span className="font-display text-xl font-bold tracking-tight">Bagira</span>
    </span>
  )
}
