import { describe, expect, it, vi } from 'vitest'
import { drawHands, HAND_CONNECTIONS } from './drawHand'
import type { Landmark } from './types'

function fakeContext() {
  return {
    clearRect: vi.fn(),
    beginPath: vi.fn(),
    moveTo: vi.fn(),
    lineTo: vi.fn(),
    stroke: vi.fn(),
    arc: vi.fn(),
    fill: vi.fn(),
    lineWidth: 0,
    strokeStyle: '',
    fillStyle: '',
    lineCap: 'butt' as CanvasLineCap,
  }
}

const hand = (offset = 0): Landmark[] =>
  Array.from({ length: 21 }, (_, i) => ({ x: (i + offset) / 40, y: i / 40, z: 0 }))

describe('drawHands', () => {
  it('has the 21 bones of the MediaPipe hand skeleton', () => {
    expect(HAND_CONNECTIONS).toHaveLength(21)
    const indices = new Set(HAND_CONNECTIONS.flat())
    expect(indices.size).toBe(21)
  })

  it('draws one line per bone and one dot per landmark, for every hand', () => {
    const ctx = fakeContext()
    drawHands(ctx, 640, 480, [hand(), hand(5)])
    expect(ctx.lineTo).toHaveBeenCalledTimes(2 * 21)
    expect(ctx.arc).toHaveBeenCalledTimes(2 * 21)
  })

  it('scales normalised coordinates to canvas pixels', () => {
    const ctx = fakeContext()
    drawHands(ctx, 200, 100, [[{ x: 0.5, y: 0.5, z: 0 }]])
    expect(ctx.arc).toHaveBeenCalledWith(100, 50, expect.any(Number), 0, Math.PI * 2)
  })

  it('only clears the canvas when no hands are present', () => {
    const ctx = fakeContext()
    drawHands(ctx, 640, 480, [])
    expect(ctx.clearRect).toHaveBeenCalledWith(0, 0, 640, 480)
    expect(ctx.arc).not.toHaveBeenCalled()
  })
})
