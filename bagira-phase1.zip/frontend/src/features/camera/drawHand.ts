import type { Landmark } from './types'

// MediaPipe hand skeleton: pairs of landmark indices to join with a line.
export const HAND_CONNECTIONS: readonly (readonly [number, number])[] = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [0, 5], [5, 6], [6, 7], [7, 8],
  [5, 9], [9, 10], [10, 11], [11, 12],
  [9, 13], [13, 14], [14, 15], [15, 16],
  [13, 17], [17, 18], [18, 19], [19, 20],
  [0, 17],
]
export const FINGERTIPS = new Set([4, 8, 12, 16, 20])

const JADE = '#3fd9a8'
const BONE = '#ece6d8'
const AMBER = '#f0a830'

type Ctx = Pick<
  CanvasRenderingContext2D,
  'clearRect' | 'beginPath' | 'moveTo' | 'lineTo' | 'stroke' | 'arc' | 'fill'
> & { lineWidth: number; strokeStyle: unknown; fillStyle: unknown; lineCap: CanvasLineCap }

export function clearCanvas(ctx: Ctx, width: number, height: number): void {
  ctx.clearRect(0, 0, width, height)
}

/** Clears a canvas if it has a 2D context (it never lacks one in a real browser; tests may). */
export function clearCanvasElement(canvas: HTMLCanvasElement): void {
  const ctx = canvas.getContext('2d')
  if (ctx) clearCanvas(ctx, canvas.width, canvas.height)
}

/** Draws every hand in canvas pixels. Landmarks are normalised (0..1) as MediaPipe returns them. */
export function drawHands(ctx: Ctx, width: number, height: number, hands: Landmark[][]): void {
  clearCanvas(ctx, width, height)
  const unit = Math.max(width, height) / 640 // keeps strokes readable at any video size
  for (const landmarks of hands) {
    ctx.lineWidth = Math.max(2, 3 * unit)
    ctx.lineCap = 'round'
    ctx.strokeStyle = JADE
    for (const [a, b] of HAND_CONNECTIONS) {
      const from = landmarks[a]
      const to = landmarks[b]
      if (!from || !to) continue
      ctx.beginPath()
      ctx.moveTo(from.x * width, from.y * height)
      ctx.lineTo(to.x * width, to.y * height)
      ctx.stroke()
    }
    landmarks.forEach((point, index) => {
      ctx.fillStyle = FINGERTIPS.has(index) ? AMBER : BONE
      ctx.beginPath()
      ctx.arc(point.x * width, point.y * height, (FINGERTIPS.has(index) ? 6 : 4) * unit, 0, Math.PI * 2)
      ctx.fill()
    })
  }
}
