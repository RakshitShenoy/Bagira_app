export type CameraErrorKind =
  | 'denied'
  | 'no-device'
  | 'in-use'
  | 'insecure'
  | 'unsupported'
  | 'disconnected'
  | 'unknown'

export const CAMERA_ERROR_COPY: Record<CameraErrorKind, { title: string; body: string }> = {
  denied: {
    title: 'Camera access is blocked',
    body: 'Bagira needs your camera to see your hands. Allow camera access for this site from the camera or lock icon in your browser’s address bar, then try again.',
  },
  'no-device': {
    title: 'No camera found',
    body: 'Connect a webcam or check that another device is not using it, then try again.',
  },
  'in-use': {
    title: 'Your camera is busy',
    body: 'Another app or browser tab is using the camera. Close it and try again.',
  },
  insecure: {
    title: 'Camera needs a secure connection',
    body: 'Browsers only allow camera access on HTTPS pages or on localhost. Open Bagira over HTTPS.',
  },
  unsupported: {
    title: 'This browser can’t open the camera',
    body: 'Try a current version of Chrome, Edge, Safari or Firefox.',
  },
  disconnected: {
    title: 'The camera was disconnected',
    body: 'The video stopped unexpectedly. Check the connection and start the camera again.',
  },
  unknown: {
    title: 'The camera could not start',
    body: 'Something unexpected happened while opening the camera. Try again, or reload the page.',
  },
}

export function describeCameraError(error: unknown): CameraErrorKind {
  // Read `name` directly: DOMException is not always `instanceof Error` (other realms, test DOMs).
  const name =
    typeof error === 'object' && error !== null && 'name' in error ? String(error.name) : ''
  switch (name) {
    case 'NotAllowedError':
    case 'PermissionDeniedError':
      return 'denied'
    case 'NotFoundError':
    case 'DevicesNotFoundError':
    case 'OverconstrainedError':
      return 'no-device'
    case 'NotReadableError':
    case 'TrackStartError':
    case 'AbortError':
      return 'in-use'
    case 'SecurityError':
      return 'insecure'
    default:
      return 'unknown'
  }
}
