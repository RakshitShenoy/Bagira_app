def start(client):
    assert client.post("/api/v1/auth/guest").status_code == 201


def test_preferences_require_a_session(client):
    assert client.get("/api/v1/preferences").status_code == 401
    assert client.patch("/api/v1/preferences", json={"mirror_camera": False}).status_code == 401


def test_defaults(client):
    start(client)
    prefs = client.get("/api/v1/preferences").json()
    assert prefs == {
        "mirror_camera": True,
        "reduce_motion": False,
        "sound_enabled": True,
        "effects_enabled": True,
        "fullscreen_reactions": True,
        "confidence_threshold": 0.8,
        "stability_frames": 5,
        "cooldown_ms": 1500,
    }


def test_partial_update_persists(client):
    start(client)
    r = client.patch("/api/v1/preferences", json={"mirror_camera": False, "cooldown_ms": 3000})
    assert r.status_code == 200
    again = client.get("/api/v1/preferences").json()
    assert again["mirror_camera"] is False and again["cooldown_ms"] == 3000
    assert again["sound_enabled"] is True  # untouched


def test_false_values_are_saved_not_ignored(client):
    start(client)
    client.patch("/api/v1/preferences", json={"sound_enabled": False})
    assert client.get("/api/v1/preferences").json()["sound_enabled"] is False


def test_invalid_values_are_rejected_without_echoing_input(client):
    start(client)
    r = client.patch("/api/v1/preferences", json={"confidence_threshold": 7})
    assert r.status_code == 422
    assert r.json()["error"]["code"] == "validation_error"
    assert r.json()["error"]["details"][0]["field"] == "body.confidence_threshold"
    assert "input" not in r.json()["error"]["details"][0]  # submitted value is never echoed


def test_unknown_fields_are_rejected(client):
    start(client)
    r = client.patch("/api/v1/preferences", json={"is_admin": True})
    assert r.status_code == 422


def test_users_cannot_see_or_change_each_others_preferences(client, make_client):
    other = make_client()
    start(client)
    start(other)
    client.patch("/api/v1/preferences", json={"mirror_camera": False})
    assert other.get("/api/v1/preferences").json()["mirror_camera"] is True
    assert client.get("/api/v1/me").json()["id"] != other.get("/api/v1/me").json()["id"]
