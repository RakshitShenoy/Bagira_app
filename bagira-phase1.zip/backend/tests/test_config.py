import pytest
from pydantic import ValidationError

from app.core.config import INSECURE_DEFAULT_SECRET, Settings

PROD = {"env": "production", "database_url": "postgresql://u:p@db/bagira"}


def make(**kwargs) -> Settings:
    return Settings(_env_file=None, **kwargs)


def test_defaults_are_development_friendly():
    s = make()
    assert s.env == "development"
    assert s.database_url.startswith("sqlite")
    assert s.effective_docs_enabled is True
    assert s.effective_cookie_secure is False
    assert s.effective_log_json is False


def test_production_rejects_default_secret():
    with pytest.raises(ValidationError, match="BAGIRA_SECRET_KEY"):
        make(**PROD, secret_key=INSECURE_DEFAULT_SECRET)


def test_production_rejects_short_secret():
    with pytest.raises(ValidationError, match="at least 32"):
        make(**PROD, secret_key="short")


def test_production_rejects_sqlite():
    with pytest.raises(ValidationError, match="SQLite"):
        make(env="production", secret_key="x" * 40)


def test_production_defaults_are_safe():
    s = make(**PROD, secret_key="x" * 40)
    assert s.effective_cookie_secure is True
    assert s.effective_log_json is True
    assert s.effective_docs_enabled is False


@pytest.mark.parametrize("scheme", ["postgres://", "postgresql://"])
def test_postgres_urls_use_psycopg_driver(scheme):
    s = make(database_url=f"{scheme}u:p@host/db")
    assert s.database_url == "postgresql+psycopg://u:p@host/db"


def test_samesite_none_requires_secure_cookies():
    with pytest.raises(ValidationError, match="secure"):
        make(cookie_samesite="none")


def test_cors_origins_are_parsed():
    s = make(cors_origins=" https://a.example , https://b.example,, ")
    assert s.cors_origin_list == ["https://a.example", "https://b.example"]
