import { describe, expect, it } from 'vitest'
import { physicalHand } from './handedness'

describe('physicalHand', () => {
  it('swaps the label for a raw (un-mirrored) camera frame', () => {
    expect(physicalHand('Left')).toBe('Right')
    expect(physicalHand('Right')).toBe('Left')
  })

  it('keeps the label when the frame was mirrored before detection', () => {
    expect(physicalHand('Left', true)).toBe('Left')
    expect(physicalHand('Right', true)).toBe('Right')
  })

  it('reports Unknown for missing or unexpected labels', () => {
    expect(physicalHand(undefined)).toBe('Unknown')
    expect(physicalHand('Both')).toBe('Unknown')
  })
})
