import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { HandConstellation } from '../components/HandConstellation'
import { Logo } from '../components/Logo'
import { Button, ButtonLink, Spinner } from '../components/ui'
import { useSession } from '../session/SessionProvider'

export default function Landing() {
  const { status, user, startGuest, retry, error } = useSession()
  const navigate = useNavigate()
  const [starting, setStarting] = useState(false)
  const [failed, setFailed] = useState(false)

  async function enterAsGuest() {
    setStarting(true)
    setFailed(false)
    const ok = await startGuest()
    setStarting(false)
    if (ok) navigate('/app')
    else setFailed(true)
  }

  return (
    <div className="bg-ambient min-h-dvh">
      <div className="mx-auto flex min-h-dvh max-w-6xl flex-col px-6 pb-12 sm:px-10">
        <header className="flex items-center justify-between py-6">
          <Logo />
          {status === 'ready' && (
            <ButtonLink to="/app" variant="quiet">
              Open dashboard
            </ButtonLink>
          )}
        </header>

        <main className="grid flex-1 items-center gap-10 py-8 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <h1 className="text-[clamp(2.75rem,8vw,5.5rem)] leading-[0.95] font-extrabold tracking-[-0.03em]">
              Show a gesture.
              <br />
              Bagira reacts.
            </h1>
            <p className="mt-6 max-w-[34rem] text-lg text-bone/75">
              Hold up a hand to your webcam and Bagira turns the gesture into a GIF, a sound or a
              full-screen reaction. Tracking runs in your browser, so your camera video never leaves
              your device.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-3">
              {status === 'ready' && user ? (
                <ButtonLink to="/app/camera">Open the camera</ButtonLink>
              ) : (
                <Button onClick={enterAsGuest} disabled={starting || status === 'loading'}>
                  {starting ? 'Starting…' : 'Continue as guest'}
                </Button>
              )}
              <p className="text-sm text-bone/60">No sign-up needed.</p>
            </div>

            <div aria-live="polite" className="mt-5 min-h-6">
              {status === 'loading' && <Spinner label="Connecting to Bagira…" />}
              {(failed || status === 'error') && (
                <p role="alert" className="text-ember">
                  {error ?? 'Something went wrong.'}{' '}
                  <button className="underline underline-offset-4" onClick={failed ? enterAsGuest : retry}>
                    Try again
                  </button>
                </p>
              )}
            </div>
          </div>

          <HandConstellation className="mx-auto w-full max-w-md lg:max-w-none" />
        </main>

        <section aria-label="How Bagira works" className="grid gap-8 border-t border-bone/10 pt-10 sm:grid-cols-3">
          <div>
            <h2 className="text-lg font-semibold">Allow your camera</h2>
            <p className="mt-2 text-bone/70">
              Bagira asks once, and only uses the camera to find your hands.
            </p>
          </div>
          <div>
            <h2 className="text-lg font-semibold">Make a gesture</h2>
            <p className="mt-2 text-bone/70">
              Thumbs up, peace sign, a fist. Nineteen hand shapes are on the list.
            </p>
          </div>
          <div>
            <h2 className="text-lg font-semibold">Watch it react</h2>
            <p className="mt-2 text-bone/70">
              Each gesture can trigger the reaction you choose. Recognition arrives in the next
              release.
            </p>
          </div>
        </section>
      </div>
    </div>
  )
}
