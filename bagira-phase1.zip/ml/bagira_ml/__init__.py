"""Bagira machine-learning package (Phase 2)."""
