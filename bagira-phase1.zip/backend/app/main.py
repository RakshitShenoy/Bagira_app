"""Application factory."""

import logging
import re
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from app.api.health import router as health_router
from app.api.v1.router import api_router
from app.core.config import Settings, get_settings
from app.core.errors import error_response, register_exception_handlers
from app.core.logging import configure_logging, request_id_var
from app.db.session import create_db_engine, create_session_factory

_REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9_.-]{8,64}$")
access_logger = logging.getLogger("bagira.access")


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()
    configure_logging(settings)
    logger = logging.getLogger("bagira")

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        engine = create_db_engine(settings.database_url, echo=settings.db_echo)
        app.state.engine = engine
        app.state.session_factory = create_session_factory(engine)
        logger.info(
            "startup",
            extra={
                "version": settings.app_version,
                "environment": settings.env,
                "database": engine.dialect.name,
            },
        )
        yield
        engine.dispose()
        logger.info("shutdown")

    docs = settings.effective_docs_enabled
    app = FastAPI(
        title=f"{settings.app_name} API",
        version=settings.app_version,
        lifespan=lifespan,
        docs_url="/docs" if docs else None,
        redoc_url=None,
        openapi_url="/openapi.json" if docs else None,
    )
    app.state.settings = settings
    app.state.logger = logger

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PATCH", "DELETE"],
        allow_headers=["Content-Type", "X-Request-ID"],
        expose_headers=["X-Request-ID"],
    )

    @app.middleware("http")
    async def request_context(request: Request, call_next):
        incoming = request.headers.get("x-request-id", "")
        request_id = incoming if _REQUEST_ID_RE.match(incoming) else uuid.uuid4().hex
        token = request_id_var.set(request_id)
        started = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:
            logger.exception("unhandled_error")
            response = error_response(500, "internal_error", "Something went wrong on our side.")
        duration_ms = round((time.perf_counter() - started) * 1000, 1)
        response.headers["X-Request-ID"] = request_id
        if request.url.path != "/health":  # keep load-balancer probes out of the logs
            access_logger.info(
                "request",
                extra={
                    "method": request.method,
                    "path": request.url.path,
                    "status": response.status_code,
                    "duration_ms": duration_ms,
                },
            )
        request_id_var.reset(token)
        return response

    register_exception_handlers(app)
    app.include_router(health_router)
    app.include_router(api_router)
    return app


def get_asgi_app() -> FastAPI:  # `uvicorn app.main:get_asgi_app --factory`
    return create_app()
