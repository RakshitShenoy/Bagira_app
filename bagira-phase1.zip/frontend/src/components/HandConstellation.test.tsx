import { render } from '@testing-library/react'
import { describe, expect, it } from 'vitest'
import { HandConstellation } from './HandConstellation'

describe('HandConstellation', () => {
  it('draws 21 landmark points joined by 21 bones, with an accessible label', () => {
    const { container, getByRole } = render(<HandConstellation />)
    expect(container.querySelectorAll('circle')).toHaveLength(21)
    expect(container.querySelectorAll('line')).toHaveLength(21)
    expect(getByRole('img')).toHaveAccessibleName(/21 connected tracking points/)
  })
})
