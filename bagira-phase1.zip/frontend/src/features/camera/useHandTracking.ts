import { useCallback, useEffect, useRef, useState } from 'react'
import type { RefObject } from 'react'
import type { HandLandmarker } from '@mediapipe/tasks-vision'
import { clearCanvasElement, drawHands } from './drawHand'
import { physicalHand } from './handedness'
import { HandTrackingLoadError, loadHandLandmarker } from './handLandmarker'
import type { LoadErrorKind } from './handLandmarker'
import type { DetectedHand, TrackingStats } from './types'

export type TrackingStatus = 'idle' | 'loading' | 'ready' | 'error'

const EMPTY: TrackingStats = { fps: 0, inferenceMs: 0, hands: [] }
const STATS_INTERVAL_MS = 250
const MAX_CONSECUTIVE_ERRORS = 5

interface Options {
  videoRef: RefObject<HTMLVideoElement | null>
  canvasRef: RefObject<HTMLCanvasElement | null>
  enabled: boolean
  showLandmarks: boolean
}

export function useHandTracking({ videoRef, canvasRef, enabled, showLandmarks }: Options) {
  const [status, setStatus] = useState<TrackingStatus>('loading')
  const [error, setError] = useState<{ kind: LoadErrorKind; message: string } | null>(null)
  const [stats, setStats] = useState<TrackingStats>(EMPTY)
  const [attempt, setAttempt] = useState(0)
  const showRef = useRef(showLandmarks)

  useEffect(() => {
    showRef.current = showLandmarks
    const canvas = canvasRef.current
    if (!showLandmarks && canvas) clearCanvasElement(canvas)
  }, [showLandmarks, canvasRef])

  useEffect(() => {
    if (!enabled) return

    const canvasAtStart = canvasRef.current
    let cancelled = false
    let frame = 0

    const run = (landmarker: HandLandmarker) => {
      let lastVideoTime = -1
      let windowStart = performance.now()
      let frames = 0
      let inferenceTotal = 0
      let consecutiveErrors = 0

      const tick = () => {
        frame = requestAnimationFrame(tick)
        const video = videoRef.current
        const canvas = canvasRef.current
        if (!video || !canvas || video.readyState < 2 || video.videoWidth === 0) return
        if (video.currentTime === lastVideoTime) return // no new camera frame yet
        lastVideoTime = video.currentTime

        const started = performance.now()
        try {
          const result = landmarker.detectForVideo(video, started)
          const inference = performance.now() - started
          consecutiveErrors = 0

          const hands: DetectedHand[] = result.landmarks.map((landmarks, i) => {
            const category = result.handedness[i]?.[0]
            return {
              label: physicalHand(category?.categoryName),
              score: category?.score ?? 0,
              landmarks,
            }
          })

          if (canvas.width !== video.videoWidth) canvas.width = video.videoWidth
          if (canvas.height !== video.videoHeight) canvas.height = video.videoHeight
          const ctx = canvas.getContext('2d')
          if (ctx && showRef.current) {
            drawHands(ctx, canvas.width, canvas.height, result.landmarks)
          } else {
            clearCanvasElement(canvas)
          }

          frames += 1
          inferenceTotal += inference
          const elapsed = started - windowStart
          if (elapsed >= STATS_INTERVAL_MS) {
            setStats({
              fps: Math.round((frames * 1000) / elapsed),
              inferenceMs: Math.round((inferenceTotal / frames) * 10) / 10,
              hands,
            })
            windowStart = started
            frames = 0
            inferenceTotal = 0
          }
        } catch {
          consecutiveErrors += 1
          if (consecutiveErrors >= MAX_CONSECUTIVE_ERRORS) {
            cancelAnimationFrame(frame)
            setError({ kind: 'runtime', message: 'Hand tracking stopped working. Try again.' })
            setStatus('error')
          }
        }
      }
      frame = requestAnimationFrame(tick)
    }

    loadHandLandmarker()
      .then((landmarker) => {
        if (cancelled) return
        setStatus('ready')
        run(landmarker)
      })
      .catch((err: unknown) => {
        if (cancelled) return
        setError(
          err instanceof HandTrackingLoadError
            ? { kind: err.kind, message: err.message }
            : { kind: 'unknown', message: 'Hand tracking could not start.' },
        )
        setStatus('error')
      })

    return () => {
      cancelled = true
      cancelAnimationFrame(frame)
      if (canvasAtStart) clearCanvasElement(canvasAtStart)
      // Leave a clean slate for the next time the camera starts.
      setStatus('loading')
      setError(null)
      setStats(EMPTY)
    }
  }, [enabled, attempt, videoRef, canvasRef])

  const retry = useCallback(() => {
    setStatus('loading')
    setError(null)
    setAttempt((n) => n + 1)
  }, [])

  if (!enabled) return { status: 'idle' as TrackingStatus, error: null, stats: EMPTY, retry }
  return { status, error, stats, retry }
}
