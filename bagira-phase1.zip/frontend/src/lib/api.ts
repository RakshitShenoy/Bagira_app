// Empty in development (Vite proxies /api). Set VITE_API_BASE_URL when the API is on another origin.
const BASE = String(import.meta.env.VITE_API_BASE_URL ?? '').replace(/\/$/, '')

export class ApiError extends Error {
  status: number
  code: string
  requestId: string | null

  constructor(message: string, status: number, code: string, requestId: string | null = null) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.code = code
    this.requestId = requestId
  }
}

interface ErrorEnvelope {
  error?: { code?: string; message?: string; request_id?: string | null }
}

export async function api<T>(
  path: string,
  options: { method?: string; json?: unknown } = {},
): Promise<T> {
  let response: Response
  try {
    response = await fetch(`${BASE}${path}`, {
      method: options.method ?? 'GET',
      credentials: 'include',
      headers: {
        Accept: 'application/json',
        ...(options.json !== undefined ? { 'Content-Type': 'application/json' } : {}),
      },
      body: options.json !== undefined ? JSON.stringify(options.json) : undefined,
    })
  } catch {
    throw new ApiError(
      "Can't reach the Bagira server. Check your connection and try again.",
      0,
      'network_error',
    )
  }

  if (response.status === 204) return undefined as T

  const text = await response.text()
  let data: unknown = null
  try {
    data = text ? JSON.parse(text) : null
  } catch {
    // Non-JSON body (for example a proxy error page); fall through to the generic message.
  }

  if (!response.ok) {
    const envelope = (data ?? {}) as ErrorEnvelope
    throw new ApiError(
      envelope.error?.message ?? `The server returned an error (${response.status}).`,
      response.status,
      envelope.error?.code ?? 'http_error',
      envelope.error?.request_id ?? response.headers.get('x-request-id'),
    )
  }
  return data as T
}

export async function fetchReadiness(): Promise<import('./types').Readiness> {
  try {
    const response = await fetch(`${BASE}/health/ready`, { credentials: 'omit' })
    const body = (await response.json()) as Partial<import('./types').Readiness>
    return {
      status: response.ok ? 'ready' : 'unavailable',
      schema_revision: body.schema_revision ?? null,
      schema_up_to_date: body.schema_up_to_date,
    }
  } catch {
    return { status: 'unreachable' }
  }
}
