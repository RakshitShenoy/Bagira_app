// Prepares MediaPipe assets so Bagira never depends on a third-party CDN at runtime.
//   1. copies the WASM runtime from node_modules into public/mediapipe/wasm (always works offline)
//   2. downloads the Hand Landmarker model into public/models/ if it is not there yet
// Both targets are git-ignored. Set BAGIRA_SKIP_MODEL_FETCH=1 to skip the download (CI caches, offline).
// Set HAND_LANDMARKER_SHA256 to verify the downloaded file against a known hash.
import { createHash } from 'node:crypto'
import { cp, mkdir, stat, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const MODEL_URL =
  process.env.HAND_LANDMARKER_URL ??
  'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task'
const modelPath = resolve(root, 'public/models/hand_landmarker.task')

async function exists(path) {
  try {
    await stat(path)
    return true
  } catch {
    return false
  }
}

await mkdir(resolve(root, 'public/mediapipe'), { recursive: true })
await cp(
  resolve(root, 'node_modules/@mediapipe/tasks-vision/wasm'),
  resolve(root, 'public/mediapipe/wasm'),
  { recursive: true },
)
console.log('[bagira] MediaPipe WASM runtime copied to public/mediapipe/wasm')

if (await exists(modelPath)) {
  console.log('[bagira] hand_landmarker.task already present')
} else if (process.env.BAGIRA_SKIP_MODEL_FETCH === '1') {
  console.warn('[bagira] WARNING: model download skipped; the camera page will report a missing model.')
} else {
  console.log(`[bagira] downloading hand_landmarker.task from ${MODEL_URL}`)
  try {
    const res = await fetch(MODEL_URL)
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const bytes = Buffer.from(await res.arrayBuffer())
    if (bytes.length < 1_000_000) throw new Error(`file too small (${bytes.length} bytes)`)
    const sha256 = createHash('sha256').update(bytes).digest('hex')
    const expected = process.env.HAND_LANDMARKER_SHA256
    if (expected && expected.toLowerCase() !== sha256) {
      throw new Error(`checksum mismatch: expected ${expected}, got ${sha256}`)
    }
    await mkdir(dirname(modelPath), { recursive: true })
    await writeFile(modelPath, bytes)
    console.log(`[bagira] saved ${bytes.length} bytes, sha256=${sha256}`)
  } catch (err) {
    console.error(`[bagira] could not download the hand landmarker model: ${err.message}`)
    console.error('         Download it manually (see docs/DEVELOPMENT.md) or set BAGIRA_SKIP_MODEL_FETCH=1.')
    process.exit(1)
  }
}
