from typing import Annotated

from fastapi import Depends, Request
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.errors import NotAuthenticated
from app.db.session import get_db
from app.models import User
from app.services.sessions import resolve_session

DbSession = Annotated[Session, Depends(get_db)]


def get_app_settings(request: Request) -> Settings:
    return request.app.state.settings


AppSettings = Annotated[Settings, Depends(get_app_settings)]


def get_current_user(request: Request, db: DbSession, settings: AppSettings) -> User:
    session = resolve_session(db, request.cookies.get(settings.session_cookie_name))
    if session is None:
        raise NotAuthenticated()
    return session.user


CurrentUser = Annotated[User, Depends(get_current_user)]
