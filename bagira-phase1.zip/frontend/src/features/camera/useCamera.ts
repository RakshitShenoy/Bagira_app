import { useCallback, useEffect, useRef, useState } from 'react'
import type { RefObject } from 'react'
import { describeCameraError } from './cameraErrors'
import type { CameraErrorKind } from './cameraErrors'

export type CameraStatus = 'idle' | 'requesting' | 'active' | 'error'

export interface UseCamera {
  status: CameraStatus
  error: CameraErrorKind | null
  videoRef: RefObject<HTMLVideoElement | null>
  start: () => Promise<void>
  stop: () => void
  restart: () => Promise<void>
}

export function useCamera(): UseCamera {
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const requestId = useRef(0) // lets us ignore a permission prompt that resolves after stop()
  const [status, setStatus] = useState<CameraStatus>('idle')
  const [error, setError] = useState<CameraErrorKind | null>(null)

  const release = useCallback(() => {
    streamRef.current?.getTracks().forEach((track) => track.stop())
    streamRef.current = null
    const video = videoRef.current
    if (video) {
      video.pause()
      video.srcObject = null
    }
  }, [])

  const stop = useCallback(() => {
    requestId.current += 1
    release()
    setError(null)
    setStatus('idle')
  }, [release])

  const fail = useCallback(
    (kind: CameraErrorKind) => {
      release()
      setError(kind)
      setStatus('error')
    },
    [release],
  )

  const start = useCallback(async () => {
    if (!window.isSecureContext) return fail('insecure')
    if (!navigator.mediaDevices?.getUserMedia) return fail('unsupported')

    release()
    const mine = ++requestId.current
    setError(null)
    setStatus('requesting')

    let stream: MediaStream
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      })
    } catch (err) {
      if (mine === requestId.current) fail(describeCameraError(err))
      return
    }

    if (mine !== requestId.current) {
      stream.getTracks().forEach((track) => track.stop()) // user stopped while the prompt was open
      return
    }

    streamRef.current = stream
    stream.getVideoTracks()[0]?.addEventListener('ended', () => {
      if (streamRef.current === stream) fail('disconnected')
    })

    const video = videoRef.current
    if (!video) return fail('unknown')
    video.srcObject = stream
    try {
      await video.play()
    } catch (err) {
      if (mine === requestId.current && (err as Error).name !== 'AbortError') {
        return fail('unknown')
      }
      return
    }
    if (mine === requestId.current) setStatus('active')
  }, [fail, release])

  const restart = useCallback(async () => {
    stop()
    await start()
  }, [start, stop])

  useEffect(() => release, [release]) // always turn the camera off when leaving the page

  return { status, error, videoRef, start, stop, restart }
}
