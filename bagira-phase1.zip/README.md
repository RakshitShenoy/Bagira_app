# Bagira

Bagira turns hand gestures into instant reactions. Hold a hand up to your webcam and Bagira recognises
the gesture and answers with a GIF, a sound or a full-screen effect. Hand tracking runs in your browser,
so your camera video is never uploaded.

> **Status: Phase 1 (foundation) is built. Gesture recognition is not built yet.**
> The app can open your camera and show real hand landmarks from MediaPipe, but it does not classify
> gestures or trigger reactions until Phases 2 and 3. See [docs/PROGRESS.md](docs/PROGRESS.md).

## What works today

- Landing page with **guest access** (no sign-up) backed by a real session cookie
- Dashboard, settings (mirror camera, reduce motion; saved on the server) and a live server status check
- **Camera page**: webcam permission handling, live feed, MediaPipe Hand Landmarker with 21 landmarks per
  hand, handedness, start / stop / restart, clear error and recovery states
- FastAPI backend, SQLAlchemy 2 models for the full planned schema, Alembic migration, structured logs,
  health checks, 19 gesture definitions seeded
- Docker, Docker Compose, Makefile, CI workflow

## Quick start (local development)

Requirements: Python 3.11+, Node.js 22+.

```bash
cp .env.example .env
make install        # backend venv + frontend packages + MediaPipe assets (downloads the hand model)
make migrate seed   # creates backend/bagira.db and loads the 19 gesture definitions

make backend        # terminal 1: API on http://127.0.0.1:8000
make frontend       # terminal 2: web app on http://localhost:5173
```

Open http://localhost:5173, choose **Continue as guest**, then open **Camera**.
Full instructions, tests and troubleshooting: [docs/DEVELOPMENT.md](docs/DEVELOPMENT.md).

## Run everything in Docker

```bash
cp .env.example .env
docker compose up --build      # http://localhost:8080
```

## Repository layout

| Path | Purpose |
|---|---|
| `backend/` | FastAPI app, database models, Alembic migrations, tests |
| `frontend/` | React + Vite + TypeScript + Tailwind web app |
| `ml/` | Machine-learning pipeline (Phase 2; kept separate from the app) |
| `docs/` | Architecture, database schema, development guide, progress tracker |

## Licence and data

MIT, see [LICENSE](LICENSE). Training data (HaGRID, CC BY-SA 4.0), landmark CSVs and trained models are
never committed to Git; see [ml/README.md](ml/README.md).
