import { describe, expect, it } from 'vitest'
import { api, ApiError, fetchReadiness } from './api'
import { jsonResponse, mockFetch } from '../test/helpers'

describe('api', () => {
  it('returns parsed JSON and always sends cookies', async () => {
    const fetchMock = mockFetch(() => jsonResponse({ ok: 1 }))
    await expect(api('/api/v1/me')).resolves.toEqual({ ok: 1 })
    expect(fetchMock.mock.calls[0][1]?.credentials).toBe('include')
  })

  it('turns the server error envelope into an ApiError', async () => {
    mockFetch(() =>
      jsonResponse({ error: { code: 'not_authenticated', message: 'Start a session.', request_id: 'r1' } }, 401),
    )
    const err = await api('/api/v1/me').catch((e: unknown) => e)
    expect(err).toBeInstanceOf(ApiError)
    expect(err).toMatchObject({ status: 401, code: 'not_authenticated', requestId: 'r1' })
  })

  it('reports an unreachable server as a network_error', async () => {
    mockFetch(() => {
      throw new TypeError('Failed to fetch')
    })
    await expect(api('/x')).rejects.toMatchObject({ status: 0, code: 'network_error' })
  })

  it('copes with non-JSON error pages', async () => {
    mockFetch(() => new Response('<html>Bad gateway</html>', { status: 502 }))
    await expect(api('/x')).rejects.toMatchObject({ status: 502, code: 'http_error' })
  })

  it('sends JSON bodies with the right header', async () => {
    const fetchMock = mockFetch(() => jsonResponse({}))
    await api('/x', { method: 'PATCH', json: { a: 1 } })
    const init = fetchMock.mock.calls[0][1]!
    expect(init.body).toBe('{"a":1}')
    expect((init.headers as Record<string, string>)['Content-Type']).toBe('application/json')
  })
})

describe('fetchReadiness', () => {
  it('maps 200 to ready, 503 to unavailable and a failed request to unreachable', async () => {
    mockFetch(() => jsonResponse({ schema_revision: '0001', schema_up_to_date: true }))
    expect((await fetchReadiness()).status).toBe('ready')
    mockFetch(() => jsonResponse({ schema_up_to_date: false }, 503))
    expect((await fetchReadiness()).status).toBe('unavailable')
    mockFetch(() => {
      throw new TypeError('offline')
    })
    expect((await fetchReadiness()).status).toBe('unreachable')
  })
})
