import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { GUEST, jsonResponse, mockFetch, PREFS } from '../test/helpers'
import { PreferencesProvider } from '../session/PreferencesProvider'
import CameraPage from './CameraPage'

// MediaPipe itself needs a real browser; these tests cover Bagira's own camera and UI logic.
const loadHandLandmarker = vi.fn()
vi.mock('../features/camera/handLandmarker', () => ({
  loadHandLandmarker: () => loadHandLandmarker(),
  HandTrackingLoadError: class extends Error {
    kind: string
    constructor(kind: string, message: string) {
      super(message)
      this.kind = kind
    }
  },
}))

const track = { stop: vi.fn(), addEventListener: vi.fn() }
const stream = { getTracks: () => [track], getVideoTracks: () => [track] }
const getUserMedia = vi.fn()

function renderPage() {
  return render(
    <MemoryRouter>
      <PreferencesProvider>
        <CameraPage />
      </PreferencesProvider>
    </MemoryRouter>,
  )
}

beforeEach(() => {
  track.stop.mockClear()
  getUserMedia.mockReset().mockResolvedValue(stream)
  loadHandLandmarker.mockReset()
  mockFetch((url) => (url.endsWith('/preferences') ? jsonResponse(PREFS) : jsonResponse(GUEST)))
  Object.defineProperty(window, 'isSecureContext', { value: true, configurable: true })
  Object.defineProperty(navigator, 'mediaDevices', { value: { getUserMedia }, configurable: true })
  vi.spyOn(HTMLMediaElement.prototype, 'play').mockResolvedValue()
  vi.spyOn(HTMLMediaElement.prototype, 'pause').mockImplementation(() => {})
})

describe('CameraPage', () => {
  it('explains the permission request before asking for the camera', () => {
    renderPage()
    expect(screen.getByText('Ready when you are')).toBeInTheDocument()
    expect(getUserMedia).not.toHaveBeenCalled()
  })

  it('shows clear guidance when camera permission is denied, and can retry', async () => {
    getUserMedia.mockRejectedValueOnce(new DOMException('denied', 'NotAllowedError'))
    renderPage()
    await userEvent.click(screen.getAllByRole('button', { name: 'Start camera' })[0])
    expect(await screen.findByText('Camera access is blocked')).toBeInTheDocument()

    loadHandLandmarker.mockReturnValue(new Promise(() => {}))
    await userEvent.click(screen.getByRole('button', { name: 'Try again' }))
    expect(await screen.findByRole('button', { name: 'Stop camera' })).toBeInTheDocument()
  })

  it('reports an insecure page instead of failing silently', async () => {
    Object.defineProperty(window, 'isSecureContext', { value: false, configurable: true })
    renderPage()
    await userEvent.click(screen.getAllByRole('button', { name: 'Start camera' })[0])
    expect(await screen.findByText('Camera needs a secure connection')).toBeInTheDocument()
    expect(getUserMedia).not.toHaveBeenCalled()
  })

  it('stops every camera track when the camera is stopped', async () => {
    loadHandLandmarker.mockReturnValue(new Promise(() => {}))
    renderPage()
    await userEvent.click(screen.getAllByRole('button', { name: 'Start camera' })[0])
    await userEvent.click(await screen.findByRole('button', { name: 'Stop camera' }))
    expect(track.stop).toHaveBeenCalled()
    expect(await screen.findByText('Ready when you are')).toBeInTheDocument()
  })

  it('turns the camera off when leaving the page', async () => {
    loadHandLandmarker.mockReturnValue(new Promise(() => {}))
    const { unmount } = renderPage()
    await userEvent.click(screen.getAllByRole('button', { name: 'Start camera' })[0])
    await screen.findByRole('button', { name: 'Stop camera' })
    unmount()
    expect(track.stop).toHaveBeenCalled()
  })

  it('shows a specific message when the hand tracking model is missing', async () => {
    const { HandTrackingLoadError } = await import('../features/camera/handLandmarker')
    loadHandLandmarker.mockRejectedValue(new HandTrackingLoadError('model-missing', 'model file missing'))
    renderPage()
    await userEvent.click(screen.getAllByRole('button', { name: 'Start camera' })[0])
    expect(await screen.findByText('Hand tracking model not found')).toBeInTheDocument()
  })

  it('lists detected hands with the corrected handedness and landmark count', async () => {
    const points = Array.from({ length: 21 }, (_, i) => ({ x: i / 21, y: i / 21, z: 0 }))
    loadHandLandmarker.mockResolvedValue({
      detectForVideo: () => ({
        landmarks: [points],
        handedness: [[{ categoryName: 'Left', score: 0.97 }]], // model label for the user's RIGHT hand
      }),
    })
    // jsdom has no video pipeline or canvas, so give the tracking loop something to read and draw on.
    let clock = 0
    Object.defineProperty(HTMLVideoElement.prototype, 'readyState', { get: () => 4, configurable: true })
    Object.defineProperty(HTMLVideoElement.prototype, 'videoWidth', { get: () => 640, configurable: true })
    Object.defineProperty(HTMLVideoElement.prototype, 'videoHeight', { get: () => 480, configurable: true })
    Object.defineProperty(HTMLVideoElement.prototype, 'currentTime', { get: () => ++clock, configurable: true })
    vi.spyOn(HTMLCanvasElement.prototype, 'getContext').mockReturnValue({
      clearRect: vi.fn(), beginPath: vi.fn(), moveTo: vi.fn(), lineTo: vi.fn(),
      stroke: vi.fn(), arc: vi.fn(), fill: vi.fn(),
    } as unknown as CanvasRenderingContext2D)

    renderPage()
    await userEvent.click(screen.getAllByRole('button', { name: 'Start camera' })[0])
    expect(await screen.findByText('Right hand', {}, { timeout: 3000 })).toBeInTheDocument()
    await waitFor(() => expect(screen.getByText(/97% confidence · 21 landmarks/)).toBeInTheDocument())
  })
})
