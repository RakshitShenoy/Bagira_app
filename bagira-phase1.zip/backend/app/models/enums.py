import enum


class MediaKind(enum.StrEnum):
    GIF = "gif"
    IMAGE = "image"
    SOUND = "sound"


class MediaSource(enum.StrEnum):
    CURATED = "curated"  # shipped with Bagira, owned by nobody
    UPLOAD = "upload"  # uploaded by a user
    EXTERNAL = "external"  # fetched through a provider such as Giphy or Tenor (later phase)


class MediaStatus(enum.StrEnum):
    ACTIVE = "active"
    PENDING = "pending"  # awaiting validation or review
    REJECTED = "rejected"


class Rarity(enum.StrEnum):
    COMMON = "common"
    RARE = "rare"
    EPIC = "epic"
    LEGENDARY = "legendary"


class ReactionTrigger(enum.StrEnum):
    GESTURE = "gesture"
    ROULETTE = "roulette"
    MINIGAME = "minigame"
