# Bagira ML pipeline

Separate from the web app: nothing in `backend/` imports this package, and nothing here touches the
application database.

**Status: Phase 2, not started.** This folder only reserves the structure.

Planned stages (see `docs/ARCHITECTURE.md`): dataset validation → annotation parsing → hand crops →
MediaPipe landmark extraction → normalisation → grouped train/validation/test split (by image) →
model comparison → per-class evaluation → export of the model **plus** its `preprocessing.json`.

Datasets, extracted landmarks and trained models are never committed to Git. See
`ml/data/README.md` and `ml/artifacts/README.md`.
