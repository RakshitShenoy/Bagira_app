"""Environment-driven configuration. Every setting is read from BAGIRA_* variables."""

from functools import lru_cache
from typing import Literal

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

INSECURE_DEFAULT_SECRET = "dev-only-insecure-secret-change-me"  # noqa: S105


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="BAGIRA_",
        env_file=(".env", "../.env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    env: Literal["development", "test", "production"] = "development"
    app_name: str = "Bagira"
    app_version: str = "0.1.0"

    database_url: str = "sqlite:///./bagira.db"
    db_echo: bool = False

    secret_key: str = INSECURE_DEFAULT_SECRET

    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    log_json: bool | None = None  # None = JSON in production, readable text otherwise

    # Comma-separated list of browser origins allowed to call the API with credentials.
    cors_origins: str = "http://localhost:5173,http://127.0.0.1:5173"

    session_cookie_name: str = "bagira_session"
    session_ttl_days: int = Field(default=30, ge=1, le=365)
    cookie_secure: bool | None = None  # None = secure in production only
    cookie_samesite: Literal["lax", "strict", "none"] = "lax"

    docs_enabled: bool | None = None  # None = enabled outside production

    @model_validator(mode="after")
    def _normalise_and_validate(self) -> "Settings":
        url = self.database_url
        # Hosting providers hand out postgres:// or postgresql:// URLs; use the psycopg 3 driver.
        for prefix in ("postgres://", "postgresql://"):
            if url.startswith(prefix):
                self.database_url = "postgresql+psycopg://" + url[len(prefix) :]
                break

        if self.cookie_samesite == "none" and not self.effective_cookie_secure:
            raise ValueError("BAGIRA_COOKIE_SAMESITE=none requires secure cookies")

        if self.env == "production":
            if self.secret_key == INSECURE_DEFAULT_SECRET or len(self.secret_key) < 32:
                raise ValueError(
                    "BAGIRA_SECRET_KEY must be set to a random value of at least 32 characters "
                    "in production"
                )
            if self.database_url.startswith("sqlite"):
                raise ValueError("SQLite is not supported in production; use PostgreSQL")
        return self

    @property
    def is_production(self) -> bool:
        return self.env == "production"

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def effective_log_json(self) -> bool:
        return self.is_production if self.log_json is None else self.log_json

    @property
    def effective_cookie_secure(self) -> bool:
        return self.is_production if self.cookie_secure is None else self.cookie_secure

    @property
    def effective_docs_enabled(self) -> bool:
        return (not self.is_production) if self.docs_enabled is None else self.docs_enabled


@lru_cache
def get_settings() -> Settings:
    return Settings()
