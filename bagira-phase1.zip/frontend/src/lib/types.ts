export interface User {
  id: string
  display_name: string
  is_guest: boolean
  created_at: string
}

export interface Preferences {
  mirror_camera: boolean
  reduce_motion: boolean
  sound_enabled: boolean
  effects_enabled: boolean
  fullscreen_reactions: boolean
  confidence_threshold: number
  stability_frames: number
  cooldown_ms: number
}

export type PreferencesPatch = Partial<Preferences>

export interface Readiness {
  status: 'ready' | 'unavailable' | 'unreachable'
  schema_revision?: string | null
  schema_up_to_date?: boolean
}
