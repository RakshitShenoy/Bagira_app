import uuid
from datetime import datetime
from typing import TYPE_CHECKING

import sqlalchemy as sa
from sqlalchemy import CheckConstraint, DateTime, ForeignKey, String, Uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, utcnow, uuid7

if TYPE_CHECKING:
    from app.models.achievement import UserAchievement
    from app.models.gesture import GestureMapping
    from app.models.history import ReactionEvent
    from app.models.media import MediaAsset
    from app.models.minigame import MiniGameRecord


class User(Base, TimestampMixin):
    """Everyone who uses Bagira owns one row.

    Guests are users with is_guest=true and no credentials. Creating an account later fills in
    email and password_hash on the same row, so a guest's data never has to be moved.
    """

    __tablename__ = "users"
    __table_args__ = (
        CheckConstraint("email IS NULL OR email = lower(email)", name="email_lowercase"),
        CheckConstraint(
            "is_guest OR (email IS NOT NULL AND password_hash IS NOT NULL)",
            name="account_has_credentials",
        ),
        CheckConstraint("length(display_name) >= 1", name="display_name_not_empty"),
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid7)
    is_guest: Mapped[bool] = mapped_column(nullable=False, default=True, server_default=sa.true())
    email: Mapped[str | None] = mapped_column(String(320), unique=True)
    password_hash: Mapped[str | None] = mapped_column(String(255))
    display_name: Mapped[str] = mapped_column(String(60))
    is_active: Mapped[bool] = mapped_column(nullable=False, default=True, server_default=sa.true())
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    sessions: Mapped[list["UserSession"]] = relationship(
        back_populates="user", cascade="all, delete-orphan", passive_deletes=True
    )
    preference: Mapped["UserPreference | None"] = relationship(
        back_populates="user", cascade="all, delete-orphan", passive_deletes=True, uselist=False
    )
    mappings: Mapped[list["GestureMapping"]] = relationship(
        back_populates="user", cascade="all, delete-orphan", passive_deletes=True
    )
    media_assets: Mapped[list["MediaAsset"]] = relationship(
        back_populates="owner", cascade="all, delete-orphan", passive_deletes=True
    )
    reactions: Mapped[list["ReactionEvent"]] = relationship(
        back_populates="user", cascade="all, delete-orphan", passive_deletes=True
    )
    achievements: Mapped[list["UserAchievement"]] = relationship(
        back_populates="user", cascade="all, delete-orphan", passive_deletes=True
    )
    game_records: Mapped[list["MiniGameRecord"]] = relationship(
        back_populates="user", cascade="all, delete-orphan", passive_deletes=True
    )


class UserSession(Base):
    """A browser session. Only a SHA-256 hash of the cookie token is stored, never the token."""

    __tablename__ = "user_sessions"
    __table_args__ = (
        CheckConstraint("expires_at > created_at", name="expires_after_created"),
        CheckConstraint("length(token_hash) = 64", name="token_hash_length"),
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid7)
    user_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, server_default=sa.func.now()
    )
    last_seen_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, server_default=sa.func.now()
    )
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    user_agent: Mapped[str | None] = mapped_column(String(255))

    user: Mapped[User] = relationship(back_populates="sessions")


class UserPreference(Base):
    """One row per user. Recognition tuning is stored now and used from Phase 3."""

    __tablename__ = "user_preferences"
    __table_args__ = (
        CheckConstraint(
            "confidence_threshold >= 0 AND confidence_threshold <= 1", name="confidence_range"
        ),
        CheckConstraint("stability_frames >= 1 AND stability_frames <= 60", name="stability_range"),
        CheckConstraint("cooldown_ms >= 0 AND cooldown_ms <= 60000", name="cooldown_range"),
    )

    user_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), primary_key=True
    )
    mirror_camera: Mapped[bool] = mapped_column(default=True, server_default=sa.true())
    reduce_motion: Mapped[bool] = mapped_column(default=False, server_default=sa.false())
    sound_enabled: Mapped[bool] = mapped_column(default=True, server_default=sa.true())
    effects_enabled: Mapped[bool] = mapped_column(default=True, server_default=sa.true())
    fullscreen_reactions: Mapped[bool] = mapped_column(default=True, server_default=sa.true())
    confidence_threshold: Mapped[float] = mapped_column(
        sa.Float, default=0.8, server_default=sa.text("0.8")
    )
    stability_frames: Mapped[int] = mapped_column(default=5, server_default=sa.text("5"))
    cooldown_ms: Mapped[int] = mapped_column(default=1500, server_default=sa.text("1500"))
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow, server_default=sa.func.now()
    )

    user: Mapped[User] = relationship(back_populates="preference")
