"""initial schema

Revision ID: 0001
Revises:
Create Date: 2026-11-09 06:52:44.807838
"""

from collections.abc import Sequence

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import op

revision: str = "0001"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "achievements",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("key", sa.String(length=48), nullable=False),
        sa.Column("name", sa.String(length=80), nullable=False),
        sa.Column("description", sa.String(length=255), nullable=False),
        sa.Column("threshold", sa.Integer(), server_default=sa.text("1"), nullable=False),
        sa.Column("sort_order", sa.Integer(), server_default=sa.text("0"), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default=sa.true(), nullable=False),
        sa.CheckConstraint("threshold >= 1", name=op.f("ck_achievements_threshold_positive")),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_achievements")),
        sa.UniqueConstraint("key", name=op.f("uq_achievements_key")),
    )
    op.create_table(
        "gestures",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("key", sa.String(length=32), nullable=False),
        sa.Column("label", sa.String(length=64), nullable=False),
        sa.Column("description", sa.String(length=255), server_default="", nullable=False),
        sa.Column("is_triggerable", sa.Boolean(), server_default=sa.true(), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default=sa.true(), nullable=False),
        sa.Column("sort_order", sa.Integer(), server_default=sa.text("0"), nullable=False),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_gestures")),
        sa.UniqueConstraint("key", name=op.f("uq_gestures_key")),
    )
    op.create_table(
        "users",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("is_guest", sa.Boolean(), server_default=sa.true(), nullable=False),
        sa.Column("email", sa.String(length=320), nullable=True),
        sa.Column("password_hash", sa.String(length=255), nullable=True),
        sa.Column("display_name", sa.String(length=60), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default=sa.true(), nullable=False),
        sa.Column("last_login_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.CheckConstraint(
            "email IS NULL OR email = lower(email)", name=op.f("ck_users_email_lowercase")
        ),
        sa.CheckConstraint(
            "is_guest OR (email IS NOT NULL AND password_hash IS NOT NULL)",
            name=op.f("ck_users_account_has_credentials"),
        ),
        sa.CheckConstraint(
            "length(display_name) >= 1", name=op.f("ck_users_display_name_not_empty")
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_users")),
        sa.UniqueConstraint("email", name=op.f("uq_users_email")),
    )
    op.create_table(
        "media_assets",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("owner_id", sa.Uuid(), nullable=True),
        sa.Column(
            "kind",
            sa.Enum(
                "gif",
                "image",
                "sound",
                name="media_kind",
                native_enum=False,
                create_constraint=True,
                length=16,
            ),
            nullable=False,
        ),
        sa.Column(
            "source",
            sa.Enum(
                "curated",
                "upload",
                "external",
                name="media_source",
                native_enum=False,
                create_constraint=True,
                length=16,
            ),
            nullable=False,
        ),
        sa.Column(
            "status",
            sa.Enum(
                "active",
                "pending",
                "rejected",
                name="media_status",
                native_enum=False,
                create_constraint=True,
                length=16,
            ),
            server_default="pending",
            nullable=False,
        ),
        sa.Column("title", sa.String(length=120), nullable=False),
        sa.Column("category", sa.String(length=40), nullable=True),
        sa.Column(
            "rarity",
            sa.Enum(
                "common",
                "rare",
                "epic",
                "legendary",
                name="rarity",
                native_enum=False,
                create_constraint=True,
                length=16,
            ),
            server_default="common",
            nullable=False,
        ),
        sa.Column("storage_key", sa.String(length=255), nullable=False),
        sa.Column("mime_type", sa.String(length=100), nullable=False),
        sa.Column("size_bytes", sa.BigInteger(), nullable=False),
        sa.Column("sha256", sa.String(length=64), nullable=False),
        sa.Column("width", sa.Integer(), nullable=True),
        sa.Column("height", sa.Integer(), nullable=True),
        sa.Column("duration_ms", sa.Integer(), nullable=True),
        sa.Column("license", sa.String(length=120), nullable=True),
        sa.Column("attribution", sa.String(length=255), nullable=True),
        sa.Column("source_url", sa.String(length=500), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.CheckConstraint(
            "source != 'upload' OR owner_id IS NOT NULL",
            name=op.f("ck_media_assets_upload_has_owner"),
        ),
        sa.CheckConstraint(
            "height IS NULL OR height > 0", name=op.f("ck_media_assets_height_positive")
        ),
        sa.CheckConstraint("length(sha256) = 64", name=op.f("ck_media_assets_sha256_length")),
        sa.CheckConstraint("size_bytes > 0", name=op.f("ck_media_assets_size_positive")),
        sa.CheckConstraint(
            "width IS NULL OR width > 0", name=op.f("ck_media_assets_width_positive")
        ),
        sa.ForeignKeyConstraint(
            ["owner_id"],
            ["users.id"],
            name=op.f("fk_media_assets_owner_id_users"),
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_media_assets")),
        sa.UniqueConstraint("storage_key", name=op.f("uq_media_assets_storage_key")),
    )
    with op.batch_alter_table("media_assets", schema=None) as batch_op:
        batch_op.create_index(batch_op.f("ix_media_assets_category"), ["category"], unique=False)
        batch_op.create_index(batch_op.f("ix_media_assets_owner_id"), ["owner_id"], unique=False)
        batch_op.create_index(batch_op.f("ix_media_assets_sha256"), ["sha256"], unique=False)
        batch_op.create_index("ix_media_assets_status_kind", ["status", "kind"], unique=False)

    op.create_table(
        "mini_game_records",
        sa.Column(
            "id",
            sa.BigInteger().with_variant(sa.Integer(), "sqlite"),
            autoincrement=True,
            nullable=False,
        ),
        sa.Column("user_id", sa.Uuid(), nullable=False),
        sa.Column("game_key", sa.String(length=40), nullable=False),
        sa.Column("score", sa.Integer(), nullable=False),
        sa.Column("duration_ms", sa.Integer(), nullable=True),
        sa.Column(
            "details",
            sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), "postgresql"),
            nullable=True,
        ),
        sa.Column(
            "played_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.CheckConstraint(
            "duration_ms IS NULL OR duration_ms >= 0",
            name=op.f("ck_mini_game_records_duration_non_negative"),
        ),
        sa.CheckConstraint("score >= 0", name=op.f("ck_mini_game_records_score_non_negative")),
        sa.ForeignKeyConstraint(
            ["user_id"],
            ["users.id"],
            name=op.f("fk_mini_game_records_user_id_users"),
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_mini_game_records")),
    )
    with op.batch_alter_table("mini_game_records", schema=None) as batch_op:
        batch_op.create_index(
            "ix_mini_game_records_game_score", ["game_key", "score"], unique=False
        )
        batch_op.create_index(
            "ix_mini_game_records_user_game", ["user_id", "game_key", "played_at"], unique=False
        )

    op.create_table(
        "user_achievements",
        sa.Column("user_id", sa.Uuid(), nullable=False),
        sa.Column("achievement_id", sa.Integer(), nullable=False),
        sa.Column("progress", sa.Integer(), server_default=sa.text("0"), nullable=False),
        sa.Column("unlocked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.CheckConstraint(
            "progress >= 0", name=op.f("ck_user_achievements_progress_non_negative")
        ),
        sa.ForeignKeyConstraint(
            ["achievement_id"],
            ["achievements.id"],
            name=op.f("fk_user_achievements_achievement_id_achievements"),
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["user_id"],
            ["users.id"],
            name=op.f("fk_user_achievements_user_id_users"),
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("user_id", "achievement_id", name=op.f("pk_user_achievements")),
    )
    with op.batch_alter_table("user_achievements", schema=None) as batch_op:
        batch_op.create_index(
            batch_op.f("ix_user_achievements_achievement_id"), ["achievement_id"], unique=False
        )

    op.create_table(
        "user_preferences",
        sa.Column("user_id", sa.Uuid(), nullable=False),
        sa.Column("mirror_camera", sa.Boolean(), server_default=sa.true(), nullable=False),
        sa.Column("reduce_motion", sa.Boolean(), server_default=sa.false(), nullable=False),
        sa.Column("sound_enabled", sa.Boolean(), server_default=sa.true(), nullable=False),
        sa.Column("effects_enabled", sa.Boolean(), server_default=sa.true(), nullable=False),
        sa.Column("fullscreen_reactions", sa.Boolean(), server_default=sa.true(), nullable=False),
        sa.Column(
            "confidence_threshold", sa.Float(), server_default=sa.text("0.8"), nullable=False
        ),
        sa.Column("stability_frames", sa.Integer(), server_default=sa.text("5"), nullable=False),
        sa.Column("cooldown_ms", sa.Integer(), server_default=sa.text("1500"), nullable=False),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.CheckConstraint(
            "confidence_threshold >= 0 AND confidence_threshold <= 1",
            name=op.f("ck_user_preferences_confidence_range"),
        ),
        sa.CheckConstraint(
            "cooldown_ms >= 0 AND cooldown_ms <= 60000",
            name=op.f("ck_user_preferences_cooldown_range"),
        ),
        sa.CheckConstraint(
            "stability_frames >= 1 AND stability_frames <= 60",
            name=op.f("ck_user_preferences_stability_range"),
        ),
        sa.ForeignKeyConstraint(
            ["user_id"],
            ["users.id"],
            name=op.f("fk_user_preferences_user_id_users"),
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("user_id", name=op.f("pk_user_preferences")),
    )
    op.create_table(
        "user_sessions",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("user_id", sa.Uuid(), nullable=False),
        sa.Column("token_hash", sa.String(length=64), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.Column(
            "last_seen_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("revoked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("user_agent", sa.String(length=255), nullable=True),
        sa.CheckConstraint(
            "expires_at > created_at", name=op.f("ck_user_sessions_expires_after_created")
        ),
        sa.CheckConstraint(
            "length(token_hash) = 64", name=op.f("ck_user_sessions_token_hash_length")
        ),
        sa.ForeignKeyConstraint(
            ["user_id"],
            ["users.id"],
            name=op.f("fk_user_sessions_user_id_users"),
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_user_sessions")),
        sa.UniqueConstraint("token_hash", name=op.f("uq_user_sessions_token_hash")),
    )
    with op.batch_alter_table("user_sessions", schema=None) as batch_op:
        batch_op.create_index(
            batch_op.f("ix_user_sessions_expires_at"), ["expires_at"], unique=False
        )
        batch_op.create_index(batch_op.f("ix_user_sessions_user_id"), ["user_id"], unique=False)

    op.create_table(
        "gesture_mappings",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("user_id", sa.Uuid(), nullable=False),
        sa.Column("gesture_id", sa.Integer(), nullable=False),
        sa.Column("media_id", sa.Uuid(), nullable=True),
        sa.Column("effect_key", sa.String(length=40), nullable=True),
        sa.Column("enabled", sa.Boolean(), server_default=sa.true(), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.CheckConstraint(
            "(media_id IS NOT NULL AND effect_key IS NULL) OR (media_id IS NULL AND effect_key IS NOT NULL)",
            name=op.f("ck_gesture_mappings_exactly_one_reaction"),
        ),
        sa.ForeignKeyConstraint(
            ["gesture_id"],
            ["gestures.id"],
            name=op.f("fk_gesture_mappings_gesture_id_gestures"),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["media_id"],
            ["media_assets.id"],
            name=op.f("fk_gesture_mappings_media_id_media_assets"),
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["user_id"],
            ["users.id"],
            name=op.f("fk_gesture_mappings_user_id_users"),
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_gesture_mappings")),
        sa.UniqueConstraint("user_id", "gesture_id", name="uq_gesture_mappings_user_gesture"),
    )
    with op.batch_alter_table("gesture_mappings", schema=None) as batch_op:
        batch_op.create_index(
            batch_op.f("ix_gesture_mappings_gesture_id"), ["gesture_id"], unique=False
        )
        batch_op.create_index(
            batch_op.f("ix_gesture_mappings_media_id"), ["media_id"], unique=False
        )
        batch_op.create_index(batch_op.f("ix_gesture_mappings_user_id"), ["user_id"], unique=False)

    op.create_table(
        "reaction_events",
        sa.Column(
            "id",
            sa.BigInteger().with_variant(sa.Integer(), "sqlite"),
            autoincrement=True,
            nullable=False,
        ),
        sa.Column("user_id", sa.Uuid(), nullable=False),
        sa.Column(
            "trigger",
            sa.Enum(
                "gesture",
                "roulette",
                "minigame",
                name="reaction_trigger",
                native_enum=False,
                create_constraint=True,
                length=16,
            ),
            nullable=False,
        ),
        sa.Column("gesture_id", sa.Integer(), nullable=True),
        sa.Column("media_id", sa.Uuid(), nullable=True),
        sa.Column("effect_key", sa.String(length=40), nullable=True),
        sa.Column("confidence", sa.Float(), nullable=True),
        sa.Column(
            "rarity",
            sa.Enum(
                "common",
                "rare",
                "epic",
                "legendary",
                name="rarity",
                native_enum=False,
                create_constraint=True,
                length=16,
            ),
            nullable=True,
        ),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.CheckConstraint(
            "trigger != 'gesture' OR gesture_id IS NOT NULL",
            name=op.f("ck_reaction_events_gesture_has_id"),
        ),
        sa.CheckConstraint(
            "confidence IS NULL OR (confidence >= 0 AND confidence <= 1)",
            name=op.f("ck_reaction_events_confidence_range"),
        ),
        sa.ForeignKeyConstraint(
            ["gesture_id"],
            ["gestures.id"],
            name=op.f("fk_reaction_events_gesture_id_gestures"),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["media_id"],
            ["media_assets.id"],
            name=op.f("fk_reaction_events_media_id_media_assets"),
            ondelete="SET NULL",
        ),
        sa.ForeignKeyConstraint(
            ["user_id"],
            ["users.id"],
            name=op.f("fk_reaction_events_user_id_users"),
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_reaction_events")),
    )
    with op.batch_alter_table("reaction_events", schema=None) as batch_op:
        batch_op.create_index(
            batch_op.f("ix_reaction_events_gesture_id"), ["gesture_id"], unique=False
        )
        batch_op.create_index(batch_op.f("ix_reaction_events_media_id"), ["media_id"], unique=False)
        batch_op.create_index(
            "ix_reaction_events_user_created", ["user_id", "created_at"], unique=False
        )
        batch_op.create_index(
            "ix_reaction_events_user_gesture", ["user_id", "gesture_id"], unique=False
        )


def downgrade() -> None:
    with op.batch_alter_table("reaction_events", schema=None) as batch_op:
        batch_op.drop_index("ix_reaction_events_user_gesture")
        batch_op.drop_index("ix_reaction_events_user_created")
        batch_op.drop_index(batch_op.f("ix_reaction_events_media_id"))
        batch_op.drop_index(batch_op.f("ix_reaction_events_gesture_id"))

    op.drop_table("reaction_events")
    with op.batch_alter_table("gesture_mappings", schema=None) as batch_op:
        batch_op.drop_index(batch_op.f("ix_gesture_mappings_user_id"))
        batch_op.drop_index(batch_op.f("ix_gesture_mappings_media_id"))
        batch_op.drop_index(batch_op.f("ix_gesture_mappings_gesture_id"))

    op.drop_table("gesture_mappings")
    with op.batch_alter_table("user_sessions", schema=None) as batch_op:
        batch_op.drop_index(batch_op.f("ix_user_sessions_user_id"))
        batch_op.drop_index(batch_op.f("ix_user_sessions_expires_at"))

    op.drop_table("user_sessions")
    op.drop_table("user_preferences")
    with op.batch_alter_table("user_achievements", schema=None) as batch_op:
        batch_op.drop_index(batch_op.f("ix_user_achievements_achievement_id"))

    op.drop_table("user_achievements")
    with op.batch_alter_table("mini_game_records", schema=None) as batch_op:
        batch_op.drop_index("ix_mini_game_records_user_game")
        batch_op.drop_index("ix_mini_game_records_game_score")

    op.drop_table("mini_game_records")
    with op.batch_alter_table("media_assets", schema=None) as batch_op:
        batch_op.drop_index("ix_media_assets_status_kind")
        batch_op.drop_index(batch_op.f("ix_media_assets_sha256"))
        batch_op.drop_index(batch_op.f("ix_media_assets_owner_id"))
        batch_op.drop_index(batch_op.f("ix_media_assets_category"))

    op.drop_table("media_assets")
    op.drop_table("users")
    op.drop_table("gestures")
    op.drop_table("achievements")
