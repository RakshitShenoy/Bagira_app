import pytest
from alembic.autogenerate import compare_metadata
from alembic.runtime.migration import MigrationContext
from sqlalchemy import inspect

import app.models  # noqa: F401
from alembic import command
from app.db.base import Base, uuid7
from app.db.migrations import alembic_config, current_revision, head_revision
from app.db.session import create_db_engine

EXPECTED_TABLES = {
    "users",
    "user_sessions",
    "user_preferences",
    "gestures",
    "gesture_mappings",
    "media_assets",
    "reaction_events",
    "achievements",
    "user_achievements",
    "mini_game_records",
}


def test_migration_creates_expected_tables(database_url):
    engine = create_db_engine(database_url)
    assert set(inspect(engine).get_table_names()) >= EXPECTED_TABLES
    assert current_revision(engine) == head_revision()


def test_models_and_migration_have_no_drift(database_url):
    """If this fails, a model changed without a matching Alembic migration."""
    engine = create_db_engine(database_url)
    with engine.connect() as connection:
        context = MigrationContext.configure(connection, opts={"compare_type": True})
        diff = compare_metadata(context, Base.metadata)
    assert diff == []


def test_downgrade_and_upgrade_again(database_url):
    config = alembic_config(database_url)
    config.attributes["configure_logger"] = False
    command.downgrade(config, "base")
    engine = create_db_engine(database_url)
    assert EXPECTED_TABLES.isdisjoint(set(inspect(engine).get_table_names()))
    command.upgrade(config, "head")
    assert set(inspect(create_db_engine(database_url)).get_table_names()) >= EXPECTED_TABLES


def test_uuid7_is_version_7_and_time_ordered():
    first, second = uuid7(), uuid7()
    assert first.version == 7 and first.variant == "specified in RFC 4122"
    assert first != second
    import time

    earlier = uuid7()
    time.sleep(0.01)
    assert uuid7().int > earlier.int


@pytest.mark.parametrize("table", sorted(EXPECTED_TABLES))
def test_every_foreign_key_is_indexed(database_url, table):
    """Child-side FK columns need an index (PostgreSQL does not create one automatically)."""
    inspector = inspect(create_db_engine(database_url))
    indexed = {tuple(ix["column_names"][:1]) for ix in inspector.get_indexes(table)}
    pk = tuple(inspector.get_pk_constraint(table)["constrained_columns"][:1])
    unique = {tuple(u["column_names"][:1]) for u in inspector.get_unique_constraints(table)}
    for fk in inspector.get_foreign_keys(table):
        first = tuple(fk["constrained_columns"][:1])
        assert first in indexed | {pk} | unique, f"{table}.{first} has no index"
