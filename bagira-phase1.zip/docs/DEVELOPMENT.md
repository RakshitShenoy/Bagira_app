# Development guide

## Prerequisites

- Python 3.11 or newer (3.12 tested)
- Node.js 22 or newer
- A webcam, for the camera page. Browsers allow camera access only on `http://localhost` or HTTPS.
- Optional: Docker, PostgreSQL 16

## First-time setup

```bash
cp .env.example .env
make install
make migrate seed
```

`make install` runs `npm run setup:mediapipe`, which

1. copies the MediaPipe WASM runtime from `node_modules` to `frontend/public/mediapipe/wasm`, and
2. downloads `hand_landmarker.task` to `frontend/public/models/`.

Both folders are git-ignored. If the download fails (offline, firewall), fetch the file yourself:

```bash
curl -L -o frontend/public/models/hand_landmarker.task \
  https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
```

Setting `BAGIRA_SKIP_MODEL_FETCH=1` skips the download; the camera page then shows
"Hand tracking model not found" instead of failing silently.

## Running

| Command | What it does |
|---|---|
| `make backend` | API on http://127.0.0.1:8000 (docs at `/docs` in development) |
| `make frontend` | Web app on http://localhost:5173. Vite proxies `/api` and `/health` to the API, so cookies are same-origin |
| `make db-reset` | Deletes the local SQLite file, then migrates and seeds |

Health checks: `GET /health` (process is up) and `GET /health/ready` (database reachable and migrated to the
latest revision; returns 503 otherwise).

## Tests and checks

```bash
make test              # backend + frontend
make lint              # ruff, ruff format, tsc, oxlint
```

Backend tests run against real Alembic migrations. To run the same suite on PostgreSQL:

```bash
BAGIRA_TEST_DATABASE_URL=postgresql+psycopg://user:pass@localhost:5432/bagira_test make test-backend
```

The frontend tests cover Bagira's own logic with jsdom. MediaPipe itself needs a real browser, so
**hand detection must be checked by hand**: open the camera page, show a hand, and confirm landmarks and
handedness appear. Handedness note: MediaPipe assumes a mirrored image; Bagira feeds it the raw frame and
swaps the label in `features/camera/handedness.ts`. Confirm that raising your right hand shows "Right hand".

## Database changes

1. Edit a model in `backend/app/models/`.
2. `cd backend && .venv/bin/alembic revision --autogenerate -m "describe change"`
3. **Read the generated file**: autogenerate is a draft. Check server defaults and enum constraints.
4. `make migrate`. A test fails if models and migrations drift apart.

## Docker

`docker compose up --build` starts PostgreSQL, the API (migrations and seed run on start) and nginx on
http://localhost:8080. The web image build downloads the MediaPipe model and fails if it cannot.

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| "Bagira can't reach its server" | Backend not running, or `make migrate` not run |
| `/health/ready` returns 503 | Database not migrated: `make migrate` |
| "Hand tracking model not found" | `hand_landmarker.task` missing: `npm run setup:mediapipe` |
| Camera blocked | Allow the camera in the browser's address bar; use localhost or HTTPS |
