"""Import every model so Base.metadata (and Alembic) sees all tables."""

from app.models.achievement import Achievement, UserAchievement
from app.models.gesture import Gesture, GestureMapping
from app.models.history import ReactionEvent
from app.models.media import MediaAsset
from app.models.minigame import MiniGameRecord
from app.models.user import User, UserPreference, UserSession

__all__ = [
    "Achievement",
    "Gesture",
    "GestureMapping",
    "MediaAsset",
    "MiniGameRecord",
    "ReactionEvent",
    "User",
    "UserAchievement",
    "UserPreference",
    "UserSession",
]
