# ml/data

Place local datasets here (git-ignored): the HaGRID sample (`hagrid-sample-120k-384p`), its
annotation JSON files and any landmark CSVs. HaGRID is licensed CC BY-SA 4.0; keep attribution.
