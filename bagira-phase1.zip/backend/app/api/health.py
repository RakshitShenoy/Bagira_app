from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from sqlalchemy import text

from app.db.migrations import current_revision, head_revision

router = APIRouter(tags=["health"])


@router.get("/health", summary="Liveness: the process is up")
def health(request: Request) -> dict:
    settings = request.app.state.settings
    return {
        "status": "ok",
        "app": settings.app_name,
        "version": settings.app_version,
        "environment": settings.env,
    }


@router.get("/health/ready", summary="Readiness: database reachable and schema migrated")
def ready(request: Request) -> JSONResponse:
    engine = request.app.state.engine
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        current = current_revision(engine)
    except Exception:
        request.app.state.logger.exception("readiness_check_failed")
        return JSONResponse({"status": "unavailable", "database": "unreachable"}, status_code=503)

    head = head_revision()
    up_to_date = current == head
    body = {
        "status": "ready" if up_to_date else "unavailable",
        "database": "ok",
        "schema_revision": current,
        "schema_up_to_date": up_to_date,
    }
    return JSONResponse(body, status_code=200 if up_to_date else 503)
