# ml/artifacts

Trained models and their `preprocessing.json` land here (git-ignored). Large files are shared through
Git LFS or external storage, never ordinary commits.
