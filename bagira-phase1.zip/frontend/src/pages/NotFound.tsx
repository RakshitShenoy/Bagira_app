import { Logo } from '../components/Logo'
import { ButtonLink } from '../components/ui'

export default function NotFound() {
  return (
    <div className="bg-ambient grid min-h-dvh place-items-center p-6 text-center">
      <div>
        <Logo className="mb-8" />
        <h1 className="text-4xl font-bold">That page doesn’t exist</h1>
        <p className="mt-3 text-bone/70">The link may be old, or the address mistyped.</p>
        <ButtonLink to="/" className="mt-8">
          Back to Bagira
        </ButtonLink>
      </div>
    </div>
  )
}
