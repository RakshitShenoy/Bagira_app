# Database schema

Defined in `backend/app/models/`, created by `backend/alembic/versions/0001_initial_schema.py`.
Application data only: the HaGRID dataset and ML artifacts live elsewhere.

```mermaid
erDiagram
  users ||--o{ user_sessions : has
  users ||--o| user_preferences : has
  users ||--o{ gesture_mappings : owns
  users ||--o{ media_assets : uploads
  users ||--o{ reaction_events : triggers
  users ||--o{ user_achievements : earns
  users ||--o{ mini_game_records : plays
  gestures ||--o{ gesture_mappings : "mapped by"
  gestures ||--o{ reaction_events : "recognised as"
  media_assets ||--o{ gesture_mappings : "shown for"
  media_assets ||--o{ reaction_events : "shown in"
  achievements ||--o{ user_achievements : "unlocked as"
```

| Table | Purpose | Notes |
|---|---|---|
| `users` | Guests and accounts | `is_guest`; accounts need email (lowercase, unique) and password hash |
| `user_sessions` | Browser sessions | token stored as SHA-256 hash; `expires_at`, `revoked_at` |
| `user_preferences` | One row per user | mirror camera, reduce motion, sound/effects, recognition threshold, stability frames, cooldown (ranges enforced) |
| `gestures` | Reference data: the 19 classes | `key` equals the classifier label; `is_triggerable` is false for `no_gesture` |
| `gesture_mappings` | User's reaction per gesture | unique per (user, gesture); exactly one of `media_id` or built-in `effect_key` |
| `media_assets` | GIF / image / sound metadata | bytes live in media storage; kind, source, status, rarity, licence, attribution, checksum; uploads must have an owner |
| `reaction_events` | Append-only reaction history | trigger = gesture / roulette / minigame; gesture-triggered rows must name the gesture |
| `achievements` | Reference data | key, name, threshold |
| `user_achievements` | Progress per user | `unlocked_at` is NULL while in progress |
| `mini_game_records` | Finished game rounds | score >= 0, optional JSON details; indexed for leaderboards |

**Deletion rules.** Deleting a user cascades to everything they own. A gesture that is referenced cannot be
deleted (`RESTRICT`). Deleting a media asset removes mappings that use it but keeps history rows
(`SET NULL`).

**Deliberately deferred** (derivable now, add a table only if queries need it): streak counters (computed from
`reaction_events`), rarity discoveries (from `reaction_events` + `media_assets.rarity`), upload moderation
tables, password-reset tokens.

**Timestamps** are stored as UTC. SQLite returns them without a zone, so the API layer marks them UTC.
