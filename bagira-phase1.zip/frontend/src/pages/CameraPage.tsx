import { useRef, useState } from 'react'
import { Button, Spinner, StatePanel, Switch } from '../components/ui'
import { CAMERA_ERROR_COPY } from '../features/camera/cameraErrors'
import { useCamera } from '../features/camera/useCamera'
import { useHandTracking } from '../features/camera/useHandTracking'
import { usePreferences } from '../session/PreferencesProvider'

export default function CameraPage() {
  const { preferences, update } = usePreferences()
  const mirror = preferences?.mirror_camera ?? true
  const [showLandmarks, setShowLandmarks] = useState(true)
  const [aspect, setAspect] = useState(16 / 9)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)

  const { status, error, videoRef, start, stop, restart } = useCamera()
  const active = status === 'active'
  const tracking = useHandTracking({
    videoRef,
    canvasRef,
    enabled: active,
    showLandmarks,
  })

  const cameraError = error ? CAMERA_ERROR_COPY[error] : null
  const hands = tracking.stats.hands

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">Camera</h1>
      <p className="mt-2 max-w-prose text-bone/70">
        Hand tracking runs inside your browser. Your video is never uploaded.
      </p>

      <div className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
        <section aria-label="Camera preview">
          <div
            className="relative mx-auto w-full overflow-hidden rounded-[2rem] border border-bone/15 bg-canopy"
            style={{ aspectRatio: aspect, maxHeight: 'calc(100dvh - 13rem)' }}
          >
            <div className={`absolute inset-0 ${mirror ? '-scale-x-100' : ''}`}>
              <video
                ref={videoRef}
                className="size-full object-contain"
                playsInline
                muted
                autoPlay
                aria-label="Live camera feed"
                onLoadedMetadata={(e) => {
                  const { videoWidth, videoHeight } = e.currentTarget
                  if (videoWidth && videoHeight) setAspect(videoWidth / videoHeight)
                }}
              />
              <canvas ref={canvasRef} className="absolute inset-0 size-full object-contain" />
            </div>

            {status === 'idle' && (
              <div className="absolute inset-0 grid place-items-center p-6 text-center">
                <div className="max-w-sm">
                  <h2 className="font-display text-2xl font-semibold">Ready when you are</h2>
                  <p className="mt-2 text-bone/70">
                    Your browser will ask for permission to use the camera. Bagira only uses it to
                    find your hands.
                  </p>
                  <Button className="mt-6" onClick={start}>
                    Start camera
                  </Button>
                </div>
              </div>
            )}

            {status === 'requesting' && (
              <div className="absolute inset-0 grid place-items-center bg-night/60 p-6">
                <Spinner label="Waiting for camera permission…" />
              </div>
            )}

            {status === 'error' && cameraError && (
              <div
                role="alert"
                className="absolute inset-0 grid place-items-center bg-night/85 p-6 text-center"
              >
                <div className="max-w-md">
                  <h2 className="font-display text-2xl font-semibold text-ember">
                    {cameraError.title}
                  </h2>
                  <p className="mt-2 text-bone/75">{cameraError.body}</p>
                  <Button className="mt-6" onClick={restart}>
                    Try again
                  </Button>
                </div>
              </div>
            )}

            {active && tracking.status === 'loading' && (
              <div className="absolute inset-x-0 bottom-4 flex justify-center">
                <span className="rounded-full bg-night/80 px-4 py-2 text-sm">
                  <Spinner label="Loading hand tracking…" />
                </span>
              </div>
            )}

            {active && tracking.status === 'ready' && hands.length === 0 && (
              <div className="absolute inset-x-0 bottom-4 flex justify-center">
                <span role="status" className="rounded-full bg-night/80 px-4 py-2 text-sm text-bone/80">
                  Show your hand to the camera
                </span>
              </div>
            )}
          </div>

          {tracking.status === 'error' && tracking.error && (
            <div className="mt-4">
              <StatePanel
                tone="error"
                title={
                  tracking.error.kind === 'model-missing'
                    ? 'Hand tracking model not found'
                    : 'Hand tracking could not start'
                }
                action={<Button onClick={tracking.retry}>Try again</Button>}
              >
                {tracking.error.message}
              </StatePanel>
            </div>
          )}

          <div className="mt-5 flex flex-wrap items-center gap-3">
            {status === 'idle' || status === 'error' ? (
              <Button onClick={start}>Start camera</Button>
            ) : (
              <Button variant="secondary" onClick={stop}>
                Stop camera
              </Button>
            )}
            <Button variant="quiet" onClick={restart} disabled={status === 'requesting'}>
              Restart camera
            </Button>
          </div>
        </section>

        <aside aria-label="Tracking details" className="space-y-6">
          <div className="rounded-3xl border border-bone/15 bg-canopy/80 px-6 py-2 divide-y divide-bone/10">
            <Switch
              label="Show hand landmarks"
              description="Draw the 21 tracked points on each hand."
              checked={showLandmarks}
              onChange={setShowLandmarks}
            />
            <Switch
              label="Mirror preview"
              description="Flip the picture like a mirror. Saved to your settings."
              checked={mirror}
              onChange={(next) => void update({ mirror_camera: next })}
              disabled={!preferences}
            />
          </div>

          <div className="rounded-3xl border border-bone/15 bg-canopy/80 p-6">
            <h2 className="font-display text-lg font-semibold">Hands in view</h2>
            {!active && <p className="mt-2 text-bone/65">Start the camera to see tracked hands.</p>}
            {active && hands.length === 0 && (
              <p className="mt-2 text-bone/65">No hands detected yet.</p>
            )}
            <ul className="mt-3 space-y-3">
              {hands.map((hand, i) => (
                <li key={i} className="rounded-2xl bg-night/70 p-4">
                  <p className="font-medium">
                    {hand.label === 'Unknown' ? 'Hand' : `${hand.label} hand`}
                  </p>
                  <p className="mt-1 text-sm text-bone/65 tabular-nums">
                    {Math.round(hand.score * 100)}% confidence · {hand.landmarks.length} landmarks
                  </p>
                </li>
              ))}
            </ul>
            {active && tracking.status === 'ready' && (
              <dl className="mt-4 grid grid-cols-2 gap-3 text-sm tabular-nums">
                <div>
                  <dt className="text-bone/60">Frames per second</dt>
                  <dd className="text-lg font-semibold">{tracking.stats.fps}</dd>
                </div>
                <div>
                  <dt className="text-bone/60">Tracking time</dt>
                  <dd className="text-lg font-semibold">{tracking.stats.inferenceMs} ms</dd>
                </div>
              </dl>
            )}
          </div>

          <p className="text-sm text-bone/60">
            Gesture recognition and reactions arrive in the next phase. Right now Bagira shows what
            your camera and hand tracking can see.
          </p>
        </aside>
      </div>
    </div>
  )
}
